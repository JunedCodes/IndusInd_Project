# Databricks notebook source
crif_schema=StructType([StructField('ACCOUNTS-SUMMARY',
            StructType([
                 StructField('DERIVED-ATTRIBUTES',
            StructType([
                 StructField('AVERAGE-ACCOUNT-AGE-MONTH', LongType(), True),
                 StructField('AVERAGE-ACCOUNT-AGE-YEAR', LongType(), True),
                 StructField('INQUIRIES-IN-LAST-SIX-MONTHS', LongType(), True),
                 StructField('LENGTH-OF-CREDIT-HISTORY-MONTH', LongType(), True),
                 StructField('LENGTH-OF-CREDIT-HISTORY-YEAR', LongType(), True),
                 StructField('NEW-ACCOUNTS-IN-LAST-SIX-MONTHS', LongType(), True),
                 StructField('NEW-DELINQ-ACCOUNT-IN-LAST-SIX-MONTHS', LongType(), True)]), True),
                 StructField('PRIMARY-ACCOUNTS-SUMMARY',
            StructType([
                 StructField('PRIMARY-ACTIVE-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('PRIMARY-CURRENT-BALANCE', LongType(), True),
                 StructField('PRIMARY-DISBURSED-AMOUNT', LongType(), True),
                 StructField('PRIMARY-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('PRIMARY-OVERDUE-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('PRIMARY-SANCTIONED-AMOUNT', LongType(), True),
                 StructField('PRIMARY-SECURED-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('PRIMARY-UNSECURED-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('PRIMARY-UNTAGGED-NUMBER-OF-ACCOUNTS', LongType(), True)]), True),
                 StructField('SECONDARY-ACCOUNTS-SUMMARY',
            StructType([
                 StructField('SECONDARY-ACTIVE-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('SECONDARY-CURRENT-BALANCE', LongType(), True),
                 StructField('SECONDARY-DISBURSED-AMOUNT', LongType(), True),
                 StructField('SECONDARY-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('SECONDARY-OVERDUE-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('SECONDARY-SANCTIONED-AMOUNT', LongType(), True),
                 StructField('SECONDARY-SECURED-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('SECONDARY-UNSECURED-NUMBER-OF-ACCOUNTS', LongType(), True),
                 StructField('SECONDARY-UNTAGGED-NUMBER-OF-ACCOUNTS', LongType(), True)]), True)]), True),
                 StructField('ALERTS',
            StructType([
                 StructField('ALERT',
            StructType([
                 StructField('ALERT-DESC', StringType(), True)]), True)]), True),
                 StructField('GRP-RESPONSES',
            StructType([
                 StructField('GRP-RESPONSE-LIST',
            StructType([
                 StructField('GRP-RESPONSE', ArrayType(
            StructType([
                 StructField('ADDRESSES',
            StructType([
                 StructField('ADDRESS', StringType(), True)]), True),
                 StructField('AGE', LongType(), True),
                 StructField('BRANCH', StringType(), True),
                 StructField('CNSMRMBRID', StringType(), True),
                 StructField('DOB', StringType(), True),
                 StructField('GROUP-CREATION-DATE', StringType(), True),
                 StructField('GROUP-DETAILS',
            StructType([
                 StructField('GROUP-ID', StringType(), True),
                 StructField('TOT-ACCOUNTS', LongType(), True),
                 StructField('TOT-CURRENT-BAL', LongType(), True),
                 StructField('TOT-DISBURSED-AMT', LongType(), True),
                 StructField('TOT-DPD-30', LongType(), True),
                 StructField('TOT-DPD-60', LongType(), True),
                 StructField('TOT-DPD-90', LongType(), True)]), True),
                 StructField('IDS',
            StructType([
                 StructField('ID', ArrayType(
            StructType([
                 StructField('TYPE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('INSERT-DATE', StringType(), True),
                 StructField('KENDRA', StringType(), True),
                 StructField('LOAN-DETAIL',
            StructType([
                 StructField('ACCT-NUMBER', StringType(), True),
                 StructField('ACCT-TYPE', StringType(), True),
                 StructField('ACTIVE-BORROWERS', StringType(), True),
                 StructField('CLOSED-DT', StringType(), True),
                 StructField('COMBINED-PAYMENT-HISTORY', StringType(), True),
                 StructField('COMMENT', StringType(), True),
                 StructField('CURRENT-BAL', LongType(), True),
                 StructField('DISBURSED-AMT', LongType(), True),
                 StructField('DISBURSED-DT', StringType(), True),
                 StructField('DPD', LongType(), True),
                 StructField('FREQ', StringType(), True),
                 StructField('INFO-AS-ON', StringType(), True),
                 StructField('INQ-CNT', LongType(), True),
                 StructField('INSTALLMENT-AMT', LongType(), True),
                 StructField('NO-OF-BORROWERS', LongType(), True),
                 StructField('OVERDUE-AMT', LongType(), True),
                 StructField('RECENT-DELINQ-DT', StringType(), True),
                 StructField('STATUS', StringType(), True),
                 StructField('WRITE-OFF-AMT', DoubleType(), True)]), True),
                 StructField('MATCHED-TYPE', StringType(), True),
                 StructField('MFI', StringType(), True),
                 StructField('MFI-ID', StringType(), True),
                 StructField('NAME', StringType(), True),
                 StructField('PHONES',
            StructType([
                 StructField('PHONE', ArrayType(LongType(), True),
                 True)]), True),
                 StructField('RELATIONS',
            StructType([
                 StructField('RELATION', ArrayType(
            StructType([
                 StructField('NAME', StringType(), True),
                 StructField('TYPE', StringType(), True)]), True),
                 True)]), True),
                 StructField('groupId', StringType(), True),
                 StructField('reportDt', StringType(), True)]), True),
                 True)]), True),
                 StructField('PRIMARY-SUMMARY',
            StructType([
                 StructField('MAX-WORST-DELEQUENCY', LongType(), True),
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('TOTAL-OTHER-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OTHER-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OTHER-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True),
                 StructField('SECONDARY-SUMMARY',
            StructType([
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True),
                 StructField('SUMMARY',
            StructType([
                 StructField('ERRORS', StringType(), True),
                 StructField('MAX-WORST-DELEQUENCY', LongType(), True),
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('OWN-MFI-INDECATOR', BooleanType(), True),
                 StructField('STATUS', StringType(), True),
                 StructField('TOTAL-OTHER-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OTHER-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OTHER-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True)]), True),
                 StructField('HEADER',
            StructType([
                 StructField('BATCH-ID', LongType(), True),
                 StructField('DATE-OF-ISSUE', StringType(), True),
                 StructField('DATE-OF-REQUEST', StringType(), True),
                 StructField('PREPARED-FOR', StringType(), True),
                 StructField('PREPARED-FOR-ID', StringType(), True),
                 StructField('REPORT-ID', StringType(), True)]), True),
                 StructField('INDV-RESPONSES',
            StructType([
                 StructField('INDV-RESPONSE-LIST',
            StructType([
                 StructField('INDV-RESPONSE', ArrayType(
            StructType([
                 StructField('ADDRESSES',
            StructType([
                 StructField('ADDRESS', ArrayType(StringType(), True),
                 True)]), True),
                 StructField('AGE', LongType(), True),
                 StructField('AGE-AS-ON', StringType(), True),
                 StructField('BRANCH', StringType(), True),
                 StructField('CNSMRMBRID', StringType(), True),
                 StructField('DOB', StringType(), True),
                 StructField('GROUP-DETAILS',
            StructType([
                 StructField('GROUP-ID', StringType(), True),
                 StructField('TOT-ACCOUNTS', LongType(), True),
                 StructField('TOT-CURRENT-BAL', LongType(), True),
                 StructField('TOT-DISBURSED-AMT', LongType(), True),
                 StructField('TOT-DPD-30', LongType(), True),
                 StructField('TOT-DPD-60', LongType(), True),
                 StructField('TOT-DPD-90', LongType(), True)]), True),
                 StructField('IDS',
            StructType([
                 StructField('ID', ArrayType(
            StructType([
                 StructField('TYPE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('INSERT-DATE', StringType(), True),
                 StructField('KENDRA', StringType(), True),
                 StructField('LOAN-DETAIL',
            StructType([
                 StructField('ACCT-NUMBER', StringType(), True),
                 StructField('ACCT-TYPE', StringType(), True),
                 StructField('CLOSED-DT', StringType(), True),
                 StructField('COMBINED-PAYMENT-HISTORY', StringType(), True),
                 StructField('CURRENT-BAL', LongType(), True),
                 StructField('DISBURSED-AMT', LongType(), True),
                 StructField('DISBURSED-DT', StringType(), True),
                 StructField('DPD', LongType(), True),
                 StructField('FREQ', StringType(), True),
                 StructField('INFO-AS-ON', StringType(), True),
                 StructField('INQ-CNT', LongType(), True),
                 StructField('INSTALLMENT-AMT', LongType(), True),
                 StructField('LOAN-COMMENTS', StringType(), True),
                 StructField('LOAN-CYCLE-ID', LongType(), True),
                 StructField('OVERDUE-AMT', LongType(), True),
                 StructField('RECENT-DELINQ-DT', StringType(), True),
                 StructField('STATUS', StringType(), True),
                 StructField('WRITE-OFF-AMT', DoubleType(), True),
                 StructField('WRITE-OFF-DT', StringType(), True)]), True),
                 StructField('MATCHED-TYPE', StringType(), True),
                 StructField('MFI', StringType(), True),
                 StructField('MFI-ID', StringType(), True),
                 StructField('NAME', StringType(), True),
                 StructField('PHONES',
            StructType([
                 StructField('PHONE', ArrayType(StringType(), True),
                 True)]), True),
                 StructField('RELATIONS',
            StructType([
                 StructField('RELATION', ArrayType(
            StructType([
                 StructField('NAME', StringType(), True),
                 StructField('TYPE', StringType(), True)]), True),
                 True)]), True),
                 StructField('reportDt', StringType(), True)]), True),
                 True)]), True),
                 StructField('PRIMARY-SUMMARY',
            StructType([
                 StructField('MAX-WORST-DELEQUENCY', LongType(), True),
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('TOTAL-OTHER-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OTHER-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OTHER-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-OWN-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OWN-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OWN-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True),
                 StructField('SECONDARY-SUMMARY',
            StructType([
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True),
                 StructField('SUMMARY',
            StructType([
                 StructField('ERRORS', StringType(), True),
                 StructField('MAX-WORST-DELEQUENCY', LongType(), True),
                 StructField('NO-OF-ACTIVE-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-CLOSED-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-DEFAULT-ACCOUNTS', LongType(), True),
                 StructField('NO-OF-OTHER-MFIS', LongType(), True),
                 StructField('NO-OF-OWN-MFIS', LongType(), True),
                 StructField('OWN-MFI-INDECATOR', BooleanType(), True),
                 StructField('STATUS', StringType(), True),
                 StructField('TOTAL-OTHER-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OTHER-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OTHER-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-OWN-CURRENT-BALANCE', LongType(), True),
                 StructField('TOTAL-OWN-DISBURSED-AMOUNT', LongType(), True),
                 StructField('TOTAL-OWN-INSTALLMENT-AMOUNT', LongType(), True),
                 StructField('TOTAL-RESPONSES', LongType(), True)]), True)]), True),
                 StructField('INQUIRY-HISTORY',
            StructType([
                 StructField('HISTORY', ArrayType(
            StructType([
                 StructField('AMOUNT', StringType(), True),
                 StructField('INQUIRY-DATE', StringType(), True),
                 StructField('MEMBER-NAME', StringType(), True),
                 StructField('PURPOSE', StringType(), True),
                 StructField('REMARK', StringType(), True)]), True),
                 True)]), True),
                 StructField('PERSONAL-INFO-VARIATION',
            StructType([
                 StructField('ADDRESS-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('DATE-OF-BIRTH-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('DRIVING-LICENSE-VARIATIONS',
            StructType([
                 StructField('VARIATION',
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True)]), True),
                 StructField('EMAIL-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('NAME-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('PAN-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('PASSPORT-VARIATIONS',
            StructType([
                 StructField('VARIATION',
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True)]), True),
                 StructField('PHONE-NUMBER-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('RATION-CARD-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('VOTER-ID-VARIATIONS',
            StructType([
                 StructField('VARIATION', ArrayType(
            StructType([
                 StructField('REPORTED-DATE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True)]), True),
                 StructField('PRINTABLE-REPORT',
            StructType([
                 StructField('CONTENT', StringType(), True),
                 StructField('FILE-NAME', StringType(), True),
                 StructField('TYPE', StringType(), True)]), True),
                 StructField('REQUEST',
            StructType([
                 StructField('ADDRESSES',
            StructType([
                 StructField('ADDRESS', StringType(), True)]), True),
                 StructField('AGE-AS-ON', StringType(), True),
                 StructField('AKA', StringType(), True),
                 StructField('BRANCH', StringType(), True),
                 StructField('CNS-IND', BooleanType(), True),
                 StructField('CNS-SCORE', StringType(), True),
                 StructField('CREDIT-INQ-PURPS-TYP', StringType(), True),
                 StructField('CREDIT-INQ-PURPS-TYP-DESC', StringType(), True),
                 StructField('CREDIT-INQUIRY-STAGE', StringType(), True),
                 StructField('CREDIT-REQ-TYP', StringType(), True),
                 StructField('CREDIT-RPT-ID', StringType(), True),
                 StructField('CREDIT-RPT-TRN-DT-TM', LongType(), True),
                 StructField('DOB', StringType(), True),
                 StructField('EMAILS', StringType(), True),
                 StructField('FATHER', StringType(), True),
                 StructField('IDS',
            StructType([
                 StructField('ID', ArrayType(
            StructType([
                 StructField('TYPE', StringType(), True),
                 StructField('VALUE', StringType(), True)]), True),
                 True)]), True),
                 StructField('IOI', BooleanType(), True),
                 StructField('KENDRA', StringType(), True),
                 StructField('LOAN-AMOUNT', LongType(), True),
                 StructField('LOS-APP-ID', StringType(), True),
                 StructField('MBR-ID', LongType(), True),
                 StructField('MFI-GROUP', BooleanType(), True),
                 StructField('MFI-IND', BooleanType(), True),
                 StructField('MFI-SCORE', BooleanType(), True),
                 StructField('MOTHER', StringType(), True),
                 StructField('NAME', StringType(), True),
                 StructField('PHONES',
            StructType([
                 StructField('PHONE', LongType(), True)]), True),
                 StructField('SPOUSE', StringType(), True)]), True),
                 StructField('RESPONSES',
            StructType([
                 StructField('RESPONSE', ArrayType(
            StructType([
                 StructField('LOAN-DETAILS',
            StructType([
                 StructField('ACCOUNT-REMARKS', StringType(), True),
                 StructField('ACCOUNT-STATUS', StringType(), True),
                 StructField('ACCT-NUMBER', StringType(), True),
                 StructField('ACCT-TYPE', StringType(), True),
                 StructField('ACTUAL-PAYMENT', StringType(), True),
                 StructField('CASH-LIMIT', StringType(), True),
                 StructField('CLOSED-DATE', StringType(), True),
                 StructField('COMBINED-PAYMENT-HISTORY', StringType(), True),
                 StructField('CREDIT-GUARANTOR', StringType(), True),
                 StructField('CREDIT-LIMIT', StringType(), True),
                 StructField('CURRENT-BAL', StringType(), True),
                 StructField('DATE-REPORTED', StringType(), True),
                 StructField('DISBURSED-AMT', StringType(), True),
                 StructField('DISBURSED-DATE', StringType(), True),
                 StructField('INSTALLMENT-AMT', StringType(), True),
                 StructField('LAST-PAYMENT-DATE', StringType(), True),
                 StructField('LINKED-ACCOUNTS',
            StructType([
                 StructField('ACCOUNT-DETAILS',
            StructType([
                 StructField('ACCOUNT-STATUS', StringType(), True),
                 StructField('ACCT-NUMBER', StringType(), True),
                 StructField('ACCT-TYPE', StringType(), True),
                 StructField('CLOSE-DATE', StringType(), True),
                 StructField('CREDIT-GUARANTOR', StringType(), True),
                 StructField('CREDIT-LIMIT', StringType(), True),
                 StructField('CURRENT-BAL', StringType(), True),
                 StructField('DATE-REPORTED', StringType(), True),
                 StructField('DISBURSED-AMT', StringType(), True),
                 StructField('DISBURSED-DATE', StringType(), True),
                 StructField('LAST-PAYMENT-DATE', StringType(), True),
                 StructField('OVERDUE-AMT', StringType(), True),
                 StructField('OWNERSHIP-IND', StringType(), True),
                 StructField('SECURITY-DETAILS', StringType(), True)]), True)]), True),
                 StructField('MATCHED-TYPE', StringType(), True),
                 StructField('ORIGINAL-TERM', LongType(), True),
                 StructField('OVERDUE-AMT', StringType(), True),
                 StructField('OWNERSHIP-IND', StringType(), True),
                 StructField('PRINCIPAL-WRITE-OFF-AMT', StringType(), True),
                 StructField('SECURITY-DETAILS',
            StructType([
                 StructField('SECURITY-DETAIL', ArrayType(
            StructType([
                 StructField('AUTOMOBILE-TYPE', StringType(), True),
                 StructField('CHASSIS-NUMBER', StringType(), True),
                 StructField('DATE-OF-VALUE', StringType(), True),
                 StructField('ENGINE-NUMBER', StringType(), True),
                 StructField('OWNER-NAME', StringType(), True),
                 StructField('PROPERTY-ADDRESS', StringType(), True),
                 StructField('REGISTRATION-NUMBER', StringType(), True),
                 StructField('SECURITY-CHARGE', StringType(), True),
                 StructField('SECURITY-TYPE', StringType(), True),
                 StructField('SECURITY-VALUE', StringType(), True),
                 StructField('YEAR-OF-MANUFACTURE', StringType(), True)]), True),
                 True)]), True),
                 StructField('SECURITY-STATUS', StringType(), True),
                 StructField('SETTLEMENT-AMT', StringType(), True),
                 StructField('SUIT-FILED_WILFUL-DEFAULT', StringType(), True),
                 StructField('WRITE-OFF-AMT', StringType(), True),
                 StructField('WRITTEN-OFF_SETTLED-STATUS', StringType(), True)]), True)]), True),
                 True)]), True),
                 StructField('SCORES',
            StructType([
                 StructField('SCORE',
            StructType([
                 StructField('SCORE-COMMENTS', StringType(), True),
                 StructField('SCORE-FACTORS', StringType(), True),
                 StructField('SCORE-TYPE', StringType(), True),
                 StructField('SCORE-VALUE', LongType(), True)]), True)]), True),
                 StructField('SECONDARY-MATCHES',
            StructType([
 
                 StructField("NAME", StringType(), True),
                 StructField("DOB", StringType(), True),
                 StructField("ACCT-NUMBER", StringType(), True),
                 StructField("CREDIT-GUARANTOR", StringType(), True),
                 StructField("ACCT-TYPE", StringType(), True),
                 StructField("DATE-REPORTED", StringType(), True),
                 StructField("OWNERSHIP-IND", StringType(), True),
                 StructField("ACCOUNT-STATUS", StringType(), True),
                 StructField("DISBURSED-AMT", StringType(), True),
                 StructField("DISBURSED-DATE", StringType(), True),
                 StructField("LAST-PAYMENT-DATE", StringType(), True),
                 StructField("CLOSED-DATE", StringType(), True),
                 StructField("OVERDUE-AMT", StringType(), True),
                 StructField("WRITE-OFF-AMT", StringType(), True),
                 StructField("CURRENT-BAL", StringType(), True),
                 StructField("CREDIT-LIMIT", StringType(), True),
                 StructField("ACCOUNT-REMARKS", StringType(), True),
                 StructField("SECURITY-STATUS", StringType(), True),
                 StructField("FREQUENCY", StringType(), True),
                 StructField("ORIGINAL-TERM", StringType(), True),
                 StructField("TERM-TO-MATURITY", StringType(), True),
                 StructField("ACCT-IN-DISPUTE", StringType(), True),
                 StructField("SETTLEMENT-AMT", StringType(), True),
                 StructField("PRINCIPAL-WRITE-OFF-AMT", StringType(), True),
                 StructField("COMBINED-PAYMENT-HISTORY", StringType(), True),
                 StructField("MATCHED-TYPE", StringType(), True),
                 StructField("REPAYMENT-TENURE", StringType(), True),
                 StructField("SUIT-FILED-WILFUL-DEFAULT", StringType(), True),
                 StructField("WRITTEN-OFF-SETTLED-STATUS", StringType(), True),
                 StructField("CASH-LIMIT", StringType(), True),
                 StructField("ACTUAL-PAYMENT", StringType(), True),
                 StructField("INSTALLMENT-AMT", StringType(), True),
            ]), True),
                 StructField('STATUS-DETAILS',
            StructType([
                 StructField('STATUS', ArrayType(
            StructType([
                 StructField('ERRORS', StructType([
                 StructField('ERROR',
            StructType([
                 StructField('ERROR-DESCRIPTION', StringType(), True)]),True)]), True),
                 StructField('OPTION', StringType(), True),
                 StructField('OPTION-STATUS', StringType(), True)]), True), True)]), True),
                 StructField('SK', LongType(), False),True])

# COMMAND ----------

equifax_schema=StructType([
                StructField('InquiryRequestInfo', 
        StructType([
                StructField('AdditionalSearchField', LongType(), True), 
                StructField('AddrLine1', StringType(), True), 
                StructField('DOB', DateType(), True), 
                StructField('FamilyDetails', 
        StructType([
                StructField('AdditionalNameInfo', ArrayType(
        StructType([
                StructField('AdditionalName', StringType(), True), 
                StructField('AdditionalNameType', StringType(), True), 
                StructField('_seq', LongType(), True)]), True), True)]), True), 
                StructField('FirstName', StringType(), True), 
                StructField('FullName', StringType(), True), 
                StructField('Gender', LongType(), True), 
                StructField('InquiryAddresses', 
        StructType([
                StructField('InquiryAddress', 
        StructType([
                StructField('AddressLine', StringType(), True), 
                StructField('Postal', LongType(), True), 
                StructField('State', StringType(), True), 
                StructField('_seq', LongType(), True)]), True)]), True), 
                StructField('InquiryCommonAccountDetails', 
        StructType([
                StructField('InquiryAccount', 
        StructType([
                StructField('BranchIDMFI', StringType(), True), 
                StructField('KendraIDMFI', LongType(), True), 
                StructField('_seq', LongType(), True)]), True)]), True), 
                StructField('InquiryPhones', 
        StructType([
                StructField('InquiryPhone', 
        StructType([
                StructField('Number', LongType(), True), 
                StructField('PhoneType', StringType(), True), 
                StructField('_seq', LongType(), True)]), True)]), True), 
                StructField('InquiryPurpose', StringType(), True), 
                StructField('MobilePhone', LongType(), True), 
                StructField('Postal', LongType(), True), 
                StructField('RequestAccountDetails', 
        StructType([
                StructField('AccountNumber', LongType(), True), 
                StructField('BranchIDMFI', StringType(), True), 
                StructField('KendraIDMFI', LongType(), True)]), True), 
                StructField('State', StringType(), True), 
                StructField('VoterId', StringType(), True), 
                StructField('_xmlns', StringType(), True)]), True), 
                StructField('InquiryResponseHeader', 
        StructType([
                StructField('ClientID', StringType(), True), 
                StructField('CustRefField', LongType(), True), 
                StructField('CustomerCode', StringType(), True), 
                StructField('Date', StringType(), True), 
                StructField('HitCode', LongType(), True), 
                StructField('ProductCode', StringType(), True), 
                StructField('ReportOrderNO', StringType(), True), 
                StructField('SuccessCode', LongType(), True), 
                StructField('Time', StringType(), True), 
                StructField('_xmlns', StringType(), True)]), True), 
                StructField('ReportData', 
        StructType([
                StructField('Accounts', 
        StructType([
                StructField('Microfinances', 
        StructType([
                StructField('Account', ArrayType(
        StructType([
                StructField('AccountNumber', StringType(), True), 
                StructField('AccountStatus', StringType(), True), 
                StructField('AdditionalMFIDetails', 
        StructType([
                StructField('MFIAddress', 
        StructType([
                StructField('AdditionalAddressDetails', ArrayType(
        StructType([
                StructField('MFIAddressline', StringType(), True), 
                StructField('MFIPostalPIN', LongType(), True), 
                StructField('MFIState', StringType(), True), 
                StructField('_seq', LongType(), True)]), True), True)]), True), 
                StructField('MFIClientFullname', StringType(), True), 
                StructField('MFIDOB', StringType(), True), 
                StructField('MFIGender', StringType(), True), 
                StructField('MFIIdentification', 
        StructType([
                StructField('MFIOtherID', StringType(), True), 
                StructField('MFIPANCardID', StringType(), True), 
                StructField('MFIRationCard', StringType(), True), 
                StructField('MFIUID', StringType(), True), 
                StructField('MFIVoterID', StringType(), True)]), True), 
                StructField('MemberId', LongType(), True), 
                StructField('MonthlyIncome', LongType(), True), 
                StructField('Phone', ArrayType(
        StructType([
                StructField('Number', LongType(), True), 
                StructField('_seq', LongType(), True), 
                StructField('_typeCode', StringType(), True)]), True), True)]), True), 
                StructField('AppliedAmount', LongType(), True), 
                StructField('BranchIDMFI', StringType(), True), 
                StructField('CurrentBalance', LongType(), True), 
                StructField('DateApplied', DateType(), True), 
                StructField('DateClosed', DateType(), True), 
                StructField('DateOpened', DateType(), True), 
                StructField('DateReported', DateType(), True), 
                StructField('DateSanctioned', DateType(), True), 
                StructField('DateWrittenOff', DateType(), True), 
                StructField('DaysPastDue', LongType(), True), 
                StructField('DisbursedAmount', LongType(), True), 
                StructField('DisputeCode', StringType(), True), 
                StructField('History24Months', 
        StructType([
                StructField('Month', ArrayType(
        StructType([
                StructField('PaymentStatus', StringType(), True), 
                StructField('_key', StringType(), True)]), True), True)]), True), 
                StructField('InstallmentAmount', LongType(), True), 
                StructField('Institution', StringType(), True), 
                StructField('InsurancePolicyAmount', LongType(), True), 
                StructField('KendraIDMFI', StringType(), True), 
                StructField('KeyPerson', 
        StructType([
                StructField('Name', StringType(), True), 
                StructField('RelationType', StringType(), True)]), True), 
                StructField('LastPaymentDate', DateType(), True), 
                StructField('LoanCategory', StringType(), True), 
                StructField('LoanCycleID', LongType(), True), 
                StructField('LoanPurpose', StringType(), True), 
                StructField('NoOfInstallments', LongType(), True), 
                StructField('Nominee', 
        StructType([
                StructField('Name', StringType(), True), 
                StructField('RelationType', StringType(), True)]), True), 
                StructField('NumberOfMeetingsHeld', LongType(), True), 
                StructField('NumberOfMeetingsMissed', LongType(), True), 
                StructField('PastDueAmount', LongType(), True), 
                StructField('RepaymentTenure', StringType(), True), 
                StructField('SanctionAmount', LongType(), True), 
                StructField('TypeOfInsurance', StringType(), True), 
                StructField('WriteOffAmount', LongType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), True)]), True), 
                StructField('Retails', 
        StructType([
                StructField('Account', ArrayType(
        StructType([
                StructField('AccountNumber', StringType(), True), 
                StructField('AccountStatus', StringType(), True), 
                StructField('AccountType', StringType(), True), 
                StructField('AssetClassification', StringType(), True), 
                StructField('Balance', LongType(), True), 
                StructField('CollateralType', StringType(), True), 
                StructField('CollateralValue', LongType(), True), 
                StructField('CreditLimit', LongType(), True), 
                StructField('DateClosed', DateType(), True), 
                StructField('DateOpened', DateType(), True), 
                StructField('DateReported', DateType(), True), 
                StructField('DisputeCode', StringType(), True), 
                StructField('HighCredit', LongType(), True), 
                StructField('History48Months', 
        StructType([
                StructField('Month', ArrayType(
        StructType([
                StructField('PaymentStatus', StringType(), True), 
                StructField('_key', StringType(), True)]), True), True)]), True), 
                StructField('InstallmentAmount', LongType(), True), 
                StructField('Institution', StringType(), True), 
                StructField('InterestRate', DoubleType(), True), 
                StructField('LastPayment', LongType(), True), 
                StructField('LastPaymentDate', DateType(), True), 
                StructField('Open', StringType(), True), 
                StructField('OwnershipType', StringType(), True), 
                StructField('PastDueAmount', LongType(), True), 
                StructField('Reason', StringType(), True), 
                StructField('RepaymentTenure', LongType(), True), 
                StructField('SanctionAmount', LongType(), True), 
                StructField('SuitFiledStatus', StringType(), True), 
                StructField('TermFrequency', StringType(), True), 
                StructField('WriteOffAmount', LongType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), True)]), True)]), True), 
                StructField('AccountsSummary', 
        StructType([
                StructField('ConsolidateCreditSummary', 
        StructType([
                StructField('Microfinance', 
        StructType([
                StructField('InstallmentAmount', DoubleType(), True), 
                StructField('NumberofOpenAccounts', LongType(), True), 
                StructField('NumberofPastDueAccounts', LongType(), True), 
                StructField('RecentAccount', StringType(), True), 
                StructField('TotalOutstandingBalance', DoubleType(), True), 
                StructField('TotalPastDueAmount', DoubleType(), True)]), True), 
                StructField('OverAll', 
        StructType([
                StructField('NumberOfOpenAccounts', LongType(), True), 
                StructField('NumberOfPastDueAccounts', LongType(), True), 
                StructField('TotalInstallmentAmount', DoubleType(), True), 
                StructField('TotalOutstandingBalance', DoubleType(), True)]), True), 
                StructField('Retail', 
        StructType([
                StructField('NumberofOpenAccounts', LongType(), True), 
                StructField('OldestAccount', StringType(), True), 
                StructField('RecentAccount', StringType(), True)]), True)]), True)]), True), 
                StructField('Disclaimer', StringType(), True), 
                StructField('Enquiries', ArrayType(
        StructType([
                StructField('Amount', LongType(), True), 
                StructField('Date', DateType(), True), 
                StructField('Institution', StringType(), True), 
                StructField('RequestPurpose', StringType(), True), 
                StructField('Time', StringType(), True), 
                StructField('_seq', LongType(), True)]), True), True), 
                StructField('EquifaxScore', 
        StructType([
                StructField('MFI', 
        StructType([
                StructField('Score', 
        StructType([
                StructField('Name', StringType(), True), 
                StructField('Value', LongType(), True)]), True)]), True), 
                StructField('Retail', 
        StructType([
                StructField('Score', 
        StructType([
                StructField('Name', StringType(), True), 
                StructField('Value', LongType(), True)]), True)]), True)]), True), 
                StructField('Error', 
        StructType([
                StructField('ErrorCode', StringType(), True), 
                StructField('ErrorMsg', StringType(), True)]), True), 
                StructField('IDAndContactInfo', 
        StructType([
                StructField('AddressInfo', ArrayType(
        StructType([
                StructField('Address', StringType(), True), 
                StructField('Postal', LongType(), True), 
                StructField('State', StringType(), True), 
                StructField('Type', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), True), 
                StructField('EmailAddressInfo', 
        StructType([
                StructField('EmailAddress', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('IdentityInfo', 
        StructType([
                StructField('DriverLicence', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('IDOther', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('NationalIDCard', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('PANId', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('PassportID', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('RationCard', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), 
                StructField('VoterID', 
        StructType([
                StructField('IdNumber', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True)]), True), 
                StructField('PersonalInfo', 
        StructType([
                StructField('Age', 
        StructType([
                StructField('Age', LongType(), True)]), True), 
                StructField('AliasNameInfo', 
        StructType([
                StructField('AliasName', StringType(), True)]), True), 
                StructField('DateOfBirth', DateType(), True), 
                StructField('FamilyIncomeReportedDate', DateType(), True), 
                StructField('Gender', StringType(), True), 
                StructField('MonthlyFamilyIncome', LongType(), True), 
                StructField('Name', 
        StructType([
                StructField('FullName', StringType(), True)]), True), 
                StructField('Occupation', StringType(), True)]), True), 
                StructField('PhoneInfo', ArrayType(
        StructType([
                StructField('Number', LongType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True), 
                StructField('_typeCode', StringType(), True)]), True), True)]), True), 
                StructField('IncomeDetails', ArrayType(
        StructType([
                StructField('AssetOwnership', StringType(), True), 
                StructField('MonthlyExpense', LongType(), True), 
                StructField('MonthlyIncome', LongType(), True), 
                StructField('Occupation', StringType(), True), 
                StructField('PovertyIndex', StringType(), True), 
                StructField('_ReportedDate', DateType(), True), 
                StructField('_seq', LongType(), True)]), True), True), 
                StructField('_xmlns', StringType(), True)]), True)])