# Databricks notebook source
filename="nb_curated_cb_equifax"
def InquiryResponseHeader(df_equifax):
    try:
        if df_equifax is not None:
            df_inqresponseheader=df_equifax.select("SK","InquiryResponseHeader.*").drop("_xmlns")
            return df_inqresponseheader
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in InquiryResponseHeader : {e} " ,execution_log_list,filename)
        return None

# COMMAND ----------

def InquiryRequest(df_equifax):
    try:
        if df_equifax is not None:
            df_inqrequest=df_equifax.select("SK","InquiryRequestInfo.*")
            return df_inqrequest
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in InquiryRequest : {e} " ,execution_log_list,filename)
        return None

# COMMAND ----------

def InquiryRequestInfo(df_equifax):
    try:
        if df_equifax is not None:
                
            df_inquriyrequest=InquiryRequest(df_equifax)
            df_inquriyrequest=df_inquriyrequest.select("*","RequestAccountDetails.*").drop("FamilyDetails","InquiryAddresses","InquiryCommonAccountDetails","InquiryPhones","RequestAccountDetails","_xmlns")
            return df_inquriyrequest
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in InquiryRequest : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------


def ReportData(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=df_equifax.select("SK","ReportData.*").drop("_xmlns")
            return df_reportdata
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in ReportData : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def report_data(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_report_data=df_reportdata.select("SK","IDAndContactInfo.PersonalInfo.*","IDAndContactInfo.PersonalInfo.Name.*","IDAndContactInfo.PersonalInfo.Age.*","IDAndContactInfo.PersonalInfo.AliasNameInfo.*","Error.*").drop("Age","AliasNameInfo","Name")

            return df_report_data
        else:          
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in report_data : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def EmailAddressinfo(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_emailinfo=df_reportdata.select("SK","IDAndContactInfo.EmailAddressInfo.*").drop("_seq")
    
            return df_emailinfo
        else:          
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in EmailAddressinfo : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------


def Incomedetails(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_income_details = df_reportdata.selectExpr("SK","inline(IncomeDetails)").drop("_seq")
            return df_income_details
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Incomedetails : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#identityinfo
def identityinfo(df_equifax):
    try:
        df_result = None
        if df_equifax is not None:
            df_reportdata = ReportData(df_equifax)
            df_id=df_reportdata.select("SK","IDAndContactInfo.IdentityInfo.*")
            for col_name in [item for item in df_id.columns if item != 'SK']:
                df_new = df_id.select("SK", f"{col_name}.*").withColumn("Type", lit(col_name))
                if df_result is None:
                    df_result = df_new
                else:
                    df_result = df_result.union(df_new)
            df_result=df_result.drop("_seq")
           
            return df_result
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        print(f"Error in identityinfo : {e}")
        logger(logger_level_info, f"Error in identityinfo : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#accountsummary
def AccountSummary(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata = ReportData(df_equifax)
            df_accountsummary=df_reportdata.select("SK","AccountsSummary.ConsolidateCreditSummary.*")
            colList = ["Retail", "OverAll", "Microfinance"]
            for colname in colList:
                tempL = df_accountsummary.select(f"{colname}.*").columns
                
                for col_name in tempL:
                    prefix = "_Rtl" if colname == colList[0] else "_OverAll" if colname == colList[1] else "_Mfi"
                    df_accountsummary = df_accountsummary.select("*",f"{colname}.*")
                  
                    df_accountsummary = df_accountsummary.withColumnRenamed(col_name, f"{col_name}{prefix}").drop(*tempL)
            df_accountsummary=df_accountsummary.drop("Retail", "OverAll", "Microfinance")
            return df_accountsummary
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in AccountSummary : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------


def Microfinanance_data(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_mfi=df_reportdata.select("SK",explode("Accounts.Microfinances.Account").alias("mfi_account")).select("SK","mfi_account.*")
            return df_mfi
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Microfinanance_data : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def Relationship(df_equifax):
    try:
        if df_equifax is not None:
            df_mfi=Microfinanance_data(df_equifax)
            relation_list=["Nominee","KeyPerson"]
            df_relation=None
            for col in relation_list:
                df_new=df_mfi.select("SK",f"{col}.*").withColumn("Type", lit(col))
                if df_relation is None:
                    df_relation=df_new
                else:
                    df_relation = df_relation.union(df_new)

            return df_relation
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Relationship : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def Enquiries(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_enquiries = df_reportdata.selectExpr("SK","inline(Enquiries)").drop("_seq")
            return df_enquiries
        else:          
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Enquiries : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------


def AddressInfo(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_address_info = df_reportdata.selectExpr("SK","inline(IDAndContactInfo.AddressInfo)").drop("_seq")
            return df_address_info
        else:          
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in AddressInfo : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def EquifaxScore(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_equifaxscore=None
            scorelist=["MFI","Retail"]
            for cols in scorelist:
                df_score=df_reportdata.select("SK",f"EquifaxScore.{cols}.Score.*").withColumn("Type",lit(cols))
                if df_equifaxscore is None:
                    df_equifaxscore=df_score
                else:
                    df_equifaxscore=df_equifaxscore.union(df_score)
            
            return df_equifaxscore
        else:          
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in EquifaxScore : {e} " ,execution_log_list,filename)
        return None
 

# COMMAND ----------

def Retails_data(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_retails=df_reportdata.select("SK",explode("Accounts.Retails.Account").alias("Retails_account")).select("SK","Retails_account.*")
           
            return df_retails
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Retails_data : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def Retails(df_equifax):
    try:
        if df_equifax is not None:
            df_retails=Retails_data(df_equifax)
            df_retails_new=df_retails.drop("History48Months","_seq")
           
            return df_retails_new
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Retails : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def Accounthistory(df_equifax):
    try:
        if df_equifax is not None:
            df_retails = Retails_data(df_equifax) 
           
            df_mfi = Microfinanance_data(df_equifax) 
            
            microfinances_df = (
                df_mfi.select("SK","AccountNumber",explode("History24Months.Month").alias("month"))
                .select("SK","AccountNumber","month.*")
                .withColumn("Type", lit("MFI"))
               
            )
         
            retail_df = (
                df_retails.select("SK","AccountNumber",explode("History48Months.Month").alias("month"))
                .select("SK","AccountNumber","month.*")
                .withColumn("Type", lit("rtl"))
                
            )
           
            if microfinances_df is not None and retail_df is not None:
                df_accounthistory = microfinances_df.union(retail_df)
            elif microfinances_df is not None:
                df_accounthistory = microfinances_df
            elif retail_df is not None:
                df_accounthistory = retail_df
            else:
                df_accounthistory = None
          
            return df_accounthistory

        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list, filename)
    except Exception as e:
        print( f"Error in Accounthistory : {e} ")
        logger(logger_level_info, f"Error in Accounthistory : {e} ", execution_log_list, filename)
        return None


# COMMAND ----------


def Microfinanace(df_equifax):
    try:
        if df_equifax is not None:
            df_mfi=Microfinanance_data(df_equifax)
            selected_columns = [col(column) for column in df_mfi.columns if column not in ["KeyPerson", "Nominee", "History24Months", "AdditionalMFIDetails", "_seq"]]
            # Select nested struct columns using wildcard '*' and alias them appropriately
            selected_columns.extend([col("AdditionalMFIDetails.MFIIdentification.*"),
                                    col("KeyPerson.Name").alias("KeyPerson_nm"),
                                    col("KeyPerson.RelationType").alias("KeyPerson_RelationType"),
                                    col("Nominee.Name").alias("Nominee_nm"),
                                    col("Nominee.RelationType").alias("Nominee_RelationType")])
            df_microfinance = df_mfi.select(selected_columns)
            return df_microfinance
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in Microfinanace : {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

def MfiAddress(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_mfiaddress = df_reportdata.select("SK",explode("Accounts.Microfinances.Account").alias("Account")).select("SK",explode("Account.AdditionalMFIDetails.MFIAddress.AdditionalAddressDetails").alias("Adidtionaladdressdetails")).select("SK","Adidtionaladdressdetails.*").drop("_seq")
          
            return df_mfiaddress
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in MfiAddress : {e} " ,execution_log_list,filename)
        return None
    



# COMMAND ----------

def MfiPhone(df_equifax):
    try:
        if df_equifax is not None:
            df_reportdata=ReportData(df_equifax)
            df_mfiphone=df_reportdata.select("SK",explode("Accounts.Microfinances.Account.AdditionalMFIDetails.Phone").alias("phone")).select("SK",explode("phone").alias("phonecol")).select("SK","phonecol.*").drop("_seq")
          
            return df_mfiphone
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in MfiPhone : {e} " ,execution_log_list,filename)
        return None