# Databricks notebook source
pip install azure-storage-blob

# COMMAND ----------

from azure.storage.blob import BlobServiceClient

filename="nb_curated_cb_unzip.dbc"
def unzip(desti_container,source_path,account_name,adls_storage_account_key,target_blob_path):
    try:
        # Connect to the Blob Storage account
        connection_string = f"DefaultEndpointsProtocol=https;AccountName={account_name};AccountKey={adls_storage_account_key};EndpointSuffix=core.windows.net"
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)

        # Initialize counter
        file_count = 0

        # Get the list of blobs within the source folder
        blob_list = blob_service_client.get_container_client(desti_container).list_blobs(name_starts_with=source_path)
        if not blob_list:
            logger(logger_level_info, f"No files to unzip ", execution_log_list, filename)
            pass
        else: 
            for blob in blob_list:
                zip_content = blob_service_client.get_blob_client(desti_container, blob.name).download_blob().readall()
                
                # Create a target container client
                target_container_client = blob_service_client.get_container_client(desti_container)

                # # Open the zip file
                with zipfile.ZipFile(BytesIO(zip_content), 'r') as zip_file:
                    # Iterate over XML files in the zip archive
                    for file_info in zip_file.infolist():
                        if file_info.filename.endswith('.xml'):
                            # Read the XML content
                            with zip_file.open(file_info) as xml_file:
                                xml_content = xml_file.read()
                                
                                # Construct the target blob path
                                target_blob_name = target_blob_path + '/' + file_info.filename.split('/')[-1]
                        
                                # Upload the XML content to the target blob path
                                target_blob_client = target_container_client.get_blob_client(target_blob_name)
                                target_blob_client.upload_blob(xml_content, overwrite=True)
                                # Increment file count
                                file_count += 1
    
        
        return file_count
    except Exception as e:
        logger(logger_level_error, f"An error occurred in the doing unzip of files   : {str(e)}", execution_log_list, filename)
        raise Exception("An error occurred in the doing unzip of files :", str(e))
        return None