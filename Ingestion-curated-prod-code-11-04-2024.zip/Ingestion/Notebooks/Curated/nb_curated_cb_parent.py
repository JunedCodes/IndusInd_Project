# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC #Curated Layer Generic Framework for XML Flattening
# MAGIC The Curated Layer Framework for XML Flattening is specifically designed to process and transform hierarchical XML data into a structured format suitable for storage in Databricks Delta Tables. This framework facilitates the seamless integration of complex XML data sources into a curated data layer, enabling more straightforward analysis and reporting. Here's how the framework operates:
# MAGIC
# MAGIC Reading XML Data from Raw ADLS Layer The framework starts by fetching XML data stored in the raw Azure Data Lake Storage (ADLS) layer. This raw data layer typically contains unprocessed XML files, which might represent business transactions, configurations, or other data types encoded in a hierarchical format.
# MAGIC XML Flattening and Transformation XML Parsing: Utilizes robust XML parsing libraries to interpret the XML data structure, extract relevant information, and handle namespaces and attributes efficiently. Flattening Process: Converts hierarchical XML data into a flat or tabular structure. This involves identifying repeating elements that can represent rows in a table and mapping nested XML tags to columns. Data Transformation: Applies necessary transformations based on business rules. This can include converting data types, aggregating information, and restructuring data to fit the target schema and write data into delta tables.

# COMMAND ----------

# MAGIC %md
# MAGIC By using the below command we are importing required libraries for 

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_import_libraries"

# COMMAND ----------

# MAGIC %md
# MAGIC By using below command we are defining these constants, we can easily refer constants value using the appropriate constant name.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_declaring_constants"

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the Schema of Crif Xml files which we are going to passing this to dataframe 

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_curated_cb_schema"

# COMMAND ----------

# MAGIC %md
# MAGIC By Using below command we are executing logger function takes two parameters: level and message. It retrieves the current frame object, gets the current time in the 'Asia/Kolkata' timezone, and assigns a filename. Then, it prints the log message in a specific format, including the current time, log level, filename, and the provided message.
# MAGIC
# MAGIC This function can be used to log messages at different levels (e.g., DEBUG, INFO, WARN, ERROR, Common Inputs from ADLS) with the corresponding log level, timestamp, filename, and message.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_logger_function"

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the function which handles crif xml flattening framework by executing functions, creating tables according to schema.

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_curated_cb_crif_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the function which handles Equifax xml flattening framework by executing functions, creating tables according to schema.

# COMMAND ----------

# MAGIC %run "/Workspace/Repos/iblfm12644@indusind.com/BFIL_DATA_ADB/Notebooks/Curated/nb_curated_cb_equifax_functions"

# COMMAND ----------

# MAGIC %md
# MAGIC Following is for Adding the metadata columns for our delta tables

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_add_meta_data_columns"

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the code for getting parameters from adf Pipeline

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_curated_cb_get_curated_parameters_from_adf"

# COMMAND ----------

# MAGIC %md
# MAGIC Import Function to query on synapse for fetching the metadata information for further implementation

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Utils/nb_query_on_synapse"

# COMMAND ----------

# MAGIC %md
# MAGIC Below is the Main function for crif flattening which will further call individual CRIF flattening functions based on the schema & Row Tags Available

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_curated_cb_main_function"

# COMMAND ----------

# MAGIC %md
# MAGIC Passing parameter values to the ADF as on outputs which will be used further to update logs for execution

# COMMAND ----------

# MAGIC %run  "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_exe_logs_dict"

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_update_logs_to_pass_adf"

# COMMAND ----------

# MAGIC %md
# MAGIC Importing Surrogate key function which will fetch the current surrogate key from the flattened tables and increment over the same so that there will one unique SK for a XML file/response

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_curated_cb_surrogate_key_increment"

# COMMAND ----------

# MAGIC %md
# MAGIC Following function is required to unzip the preApproved zip files in adls and utilize them for further flattening 

# COMMAND ----------

# MAGIC %run "/Workspace/BFIL/Ingestion/Notebooks/Curated/nb_curated_cb_unzip"

# COMMAND ----------

# Calling function to fetch all input parameters from ADF

try:
    src_object_id,pipeline_run_id,load_from_date,load_to_date,pipeline_name,object_source, object_name, load_type,desti_container,last_load_to_date, source_path,pipeline_trigger_name,triggered_by_pipeline, archive_container,created_by,updated_by,adb_curated_source_url,adb_synapse_connection_string=get_curated_parameters_from_adf()
  
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_get_params_from_adf notebook: {str(e)}", execution_log_list, filename)

    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_get_params_from_adf notebook:", str(e))


try:
    # For creating connection between databricks to synapse
    synapse_jdbc_url = create_databricks_to_synapse_connection(adb_secret_scope_name, adb_synapse_connection_string)
    if synapse_jdbc_url is not None :
        # Configure connection between Databricks to Synapse
        logger(logger_level_info, f"The configuration of the connection between Databricks and Synapse has been successfully completed.", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_synapse_connectivity notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_synapse_connectivity notebook:", str(e))

try:  
    # To get query result from synapse 
    query_log_result_df = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, log_table_name, log_column_list)

    # Filtering the data frame of synapse query result based on the condition
    query_log_result_df = query_log_result_df.filter(
        (col("src_object_id") == src_object_id) & 
        (date_format(col("load_from_date"), "yyyy-MM-dd") == date_format(lit(load_from_date), "yyyy-MM-dd")))

    # Checking is data frame is empty or not
    if query_log_result_df.isEmpty():
        # Call the logger function with a log level and message
        logger(logger_level_error, f"The {log_table_name} DataFrame is empty, indicating an issue between Databricks and Synapse.",execution_log_list, filename)
        raise Exception(f"The {log_table_name} DataFrame is empty, indicating an issue between Databricks and Synapse.")
    
    logger(logger_level_info, f"The loading of the source system details has been successfully executed.", execution_log_list, filename)
except Exception as e:
    logger(logger_level_error, f"An error occurred in the nb_query_on_synapse notebook: {str(e)}", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    # Handle the exception or display the error message as needed
    raise Exception("An error occurred in the nb_query_on_synapse notebook:", str(e))


try:
    # Fetching exec_log_id from synapse
    exec_log_id = query_log_result_df.select(col("exec_log_id")).first()[0]

    # Checking is exec_log_id has value or not 
    if exec_log_id:
        logger(logger_level_info, f"The retrieval of exec_log_id from Synapse has been successfully completed for {object_name}.", execution_log_list, filename)
except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while fetching exec_log_id from Synapse {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while fetching exec_log_id from Synapse.", str(e))

try:  
    # To get query result from synapse 
    query_pl_src_log_result_df = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, config_table_name, config_column_list)

    # Filtering the data frame of synapse query result based on below condition
    query_pl_src_log_result_df = query_pl_src_log_result_df.filter((col("src_object_id") == src_object_id))

    # Checking is data frame is empty or not
    if query_pl_src_log_result_df.isEmpty():
        # Call the logger function with a log level and message
        logger(logger_level_error, f"The {config_table_name} DataFrame is empty; there will be an issue between Databricks and Synapse.",execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"The {config_table_name} DataFrame is empty; there will be an issue between Databricks and Synapse.")
    
    logger(logger_level_info, f"The loading of the source system details has been successfully executed.", execution_log_list, filename)
except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while executing the get_query_result_from_synapse function {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while executing the get_query_result_from_synapse function.", str(e))

try:
    # Fetching desti_path from synapse
    desti_path = query_pl_src_log_result_df.select(col("desti_path")).first()[0]
    print(desti_path)

    logger(logger_level_info, f"The fetching of desti_path from Synapse has been successfully executed: {object_name}.", execution_log_list, filename)
   
    logger(logger_level_info, f"Fetching desti_path from Synapse is: {object_name}.", execution_log_list, filename)

except Exception as e:
    # Log the error along with the traceback
    logger(logger_level_error, f"An error occurred while fetching desti_path from Synapse {str(e)}.", execution_log_list, filename)
    print(*execution_log_list,sep='\n')
    raise Exception(f"An error occurred while fetching desti_path from Synapse.", str(e))




# COMMAND ----------


# # Check if source table path exists
try :
    if source_path is not None and source_path != '':
        # Load the source data
        try:
            parts = adb_curated_source_url.split("@")
            account_name= parts[1]
            #concat source path and adls url for craeting folder path
            #for one time load we are using archive conatiner 
            if load_type == onetimeload :
                if object_source==reportmart:
                    if object_name ==instantcblogs:  
                        instant_path = f"{adb_curated_source_url}/{source_path}"
                        df_crif = spark.read.format("xml").options(rowTag="INDV-REPORT", recursiveFileLookup="true",schema=crif_schema).load(instant_path)
                        #Adding Surrogate Key Column  
                        df_crif = add_sk_column(df_crif)
                        df_equifax = spark.read.format("xml").options(rowTag="InquiryResponseType", mode="PERMISSIVE", escape='\\\\', columnNameOfCorruptRecord="_corrupt_record",recursiveFileLookup="true",schema=equifax_schema).load(instant_path)
                        df_equifax=add_sk_column_equifax(df_equifax)
                        source_row_count=df_crif.count()+df_equifax.count()
                        #call main function here
                        main_crif(df_crif,instant_path)
                        main_equifax(df_equifax,instant_path)
                       
                    try:
                        update_logs(src_object_id, df_crif, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                    except Exception as e:
                        logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                        # print(*execution_log_list,sep='\n')
                        # Handle the exception or display the error message as needed
                        raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))
                    
                    else:
                        logger(logger_level_error, f"not instant found in path", execution_log_list, filename)
                        
            
                elif object_source==cbpreaaproved:
                    if "CRIF" in object_name:
                        #unzip the code call function here that return path of targetted file
                        target_blob_path_crif=target_blob_path_crif+"/"+object_name+"_"+pipeline_run_id+"/"
                        source_row_count=unzip(desti_container,source_path,account_name,adls_storage_account_key,target_blob_path_crif)
                        #creating the path for reading files of files from unzipped folder
                        target_blob_path=adb_curated_source_url+"/"+target_blob_path_crif
                      
                        try:
                            df_crif = spark.read.format("xml").options(rowTag="INDV-REPORT", recursiveFileLookup="true",schema=crif_schema).load(target_blob_path)
                            #Adding Surrogate Key Column
                            df_crif = add_sk_column(df_crif)
                            source_row_count=df_crif.count()
                            #call main function here
                            main_crif(df_crif,target_blob_path)
                        except Exception as e:
                            logger(logger_level_error, f"An error occurred in the gettting main function of crif preapproved : {str(e)}", execution_log_list, filename)
                            raise Exception("An error occurred in the gettting main function of crif preapproved :", str(e))
                        try:
                            dbutils.fs.rm(f"{target_blob_path}",True)
                        except Exception as e:
                            logger(logger_level_error, f"An error occurred in the removing unzip folders  crif preapproved : {str(e)}", execution_log_list, filename)
                            raise Exception("An error occurred in the removing unzip folders  crif preapproved:", str(e))
                        
                        
                    try:
                        update_logs(src_object_id, df_crif, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                    except Exception as e:
                        logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                        # print(*execution_log_list,sep='\n')
                        # Handle the exception or display the error message as needed
                        raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))
            #for transactional we are using raw layer container
            elif load_type == transactional:
                if object_source==reportmart:
                    if object_name ==instantcblogs:  
                        instant_path = f"{adb_curated_source_url}/{source_path}"
                        df_crif = spark.read.format("xml").options(rowTag="INDV-REPORT", recursiveFileLookup="true",schema=crif_schema).load(instant_path)
                        #Adding Surrogate Key Column  
                        df_crif = add_sk_column(df_crif)
                        df_equifax = spark.read.format("xml").options(rowTag="InquiryResponseType", mode="PERMISSIVE", escape='\\\\', columnNameOfCorruptRecord="_corrupt_record",recursiveFileLookup="true",schema=equifax_schema).load(instant_path)
                        df_equifax=add_sk_column_equifax(df_equifax)
                        source_row_count=df_crif.count()+df_equifax.count()
                        #call main function here
                        main_crif(df_crif,instant_path)
                        main_equifax(df_equifax,instant_path)
                       
                    try:
                        update_logs(src_object_id, df_crif, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                    except Exception as e:
                        logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                        # print(*execution_log_list,sep='\n')
                        # Handle the exception or display the error message as needed
                        raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))
                    
                    else:
                        logger(logger_level_error, f"not instant found in path", execution_log_list, filename)
                        
            
                elif object_source==cbpreaaproved:
                    if "CRIF" in object_name:
                        #unzip the code call function here that return path of targetted file
                        target_blob_path_crif=target_blob_path_crif+"/"+object_name+"_"+pipeline_run_id+"/"
                        source_row_count=unzip(desti_container,source_path,account_name,adls_storage_account_key,target_blob_path_crif)
                        #creating the path for reading files of files from unzipped folder
                        target_blob_path=adb_curated_source_url+"/"+target_blob_path_crif
                      
                        try:
                            df_crif = spark.read.format("xml").options(rowTag="INDV-REPORT", recursiveFileLookup="true",schema=schema).load(target_blob_path)
                            #Adding Surrogate Key Column
                            df_crif = add_sk_column(df_crif)
                            source_row_count=df_crif.count()
                            #call main function here
                            main_crif(df_crif,target_blob_path)
                        except Exception as e:
                            logger(logger_level_error, f"An error occurred in the gettting main function of crif preapproved : {str(e)}", execution_log_list, filename)
                            raise Exception("An error occurred in the gettting main function of crif preapproved :", str(e))
                        try:
                            dbutils.fs.rm(f"{target_blob_path}",True)
                        except Exception as e:
                            logger(logger_level_error, f"An error occurred in the removing unzip folders  crif preapproved : {str(e)}", execution_log_list, filename)
                            raise Exception("An error occurred in the removing unzip folders  crif preapproved:", str(e))
                          
                    try:
                        update_logs(src_object_id, df_crif, start_timestamp, log_status_success, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, log_error_success, desti_path, load_type, execution_log_list)
                    except Exception as e:
                        logger(logger_level_error, f"An error occurred in the nb_update_logs_to_pass_adf notebook: {str(e)}", execution_log_list, filename)
                        # print(*execution_log_list,sep='\n')
                        # Handle the exception or display the error message as needed
                        raise Exception("An error occurred in the nb_update_logs_to_pass_adf notebook:", str(e))
        except Exception as e:
            # Call the logger function with a log level and message
            logger(logger_level_error, f"An error occurred while creating the dataframe from the input files {str(e)}.", execution_log_list, filename)
            print(*execution_log_list,sep='\n')
            raise Exception(f"An error occurred while creating the dataframe from the input files.", str(e))
        

except Exception as e:
    # Call the logger function with a log level and message
    logger(logger_level_error, f"Incorrect {source_path}, or no files are present in the given path {str(e)}.", execution_log_list, filename)
    # print(*execution_log_list,sep='\n')
    raise Exception(f"Incorrect {source_path}, or no files are present in the given path.", str(e))


