# Databricks notebook source
# Declaring the notebook name
filename = 'nb_update_logs_to_pass_adf.dbc'

# COMMAND ----------

def update_logs(src_object_id, source_data_df, start_timestamp, status, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, error_log, desti_path, load_type, execution_log_list) :

        # Defining constants 
        end_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))

        destination_row_count = source_data_df.count()

        try:
            dbutils.notebook.exit({"curated_pipeline_execution_logs": execution_log_list, "output_to_adf": get_logs_dictionary(src_object_id, start_timestamp, end_timestamp, status, load_from_date, load_to_date, pipeline_name, pipeline_run_id, pipeline_trigger_name, source_row_count, destination_row_count, error_log)})
        except Exception as e:
            # Call the logger function with a log level and message
            logger(logger_level_error, f"the error occurred while passing the pipeline execution log dictionary to adf : {str(e)}.", execution_log_list, filename)
            print(*execution_log_list,sep='\n')
            raise Exception(f"An unexpected error occurred:", str(e))