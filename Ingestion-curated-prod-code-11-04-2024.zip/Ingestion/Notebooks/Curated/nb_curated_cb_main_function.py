# Databricks notebook source
filename='nb_curated_cb_main_function.dbc'
def main_crif(df_crif,desti_path):
    try:

        spark.sql(f"USE {adb_curated_catlog_schema}")
        instant_function_names =['contact','header','request','statusdetails','inquiryhistory', 'alert', 'groupdetails', 'loan_details','response','score','comment','secondary_matches','linked_accounts','securitydetails','variation','ids', 'relation', 'responselist','account_Summary']

        for function_name in instant_function_names:
            try:
                function = globals()[function_name]
                df_result = function(df_crif)
                if df_result is not None:
                    df_result.cache()
                    df_result=df_result.fillna('').dropDuplicates().dropna(how='all')
                    source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, object_name, load_to_date, load_type, desti_path)
                    
                    new_table_name = "crif_instant_" + function_name
            
                    source_data_df.write.format("delta").mode("append").saveAsTable(new_table_name)
                else:
                    pass
                    logger(logger_level_info, f"Operation doesn't have required columns.", execution_log_list, filename)
            except Exception as e:
                pass
                logger(logger_level_error, f"Error occurred during: {e}", execution_log_list, filename)
    except Exception as e:
        pass
        logger(logger_level_error, f"Error occurred during execution: {e}", execution_log_list, filename)


# COMMAND ----------

def main_equifax(df_equifax, desti_path):
    try:
        # spark.sql(f"USE {adb_curated_catlog_schema}")
        instant_function_names = ["Microfinanace", "Retails", "Accounthistory", "AddressInfo","EmailAddressinfo", "EquifaxScore", "Enquiries", "Relationship", "AccountSummary", "identityinfo", "Incomedetails", "report_data", "InquiryRequestInfo", "InquiryResponseHeader", "process_inquiry_data","MfiAddress","MfiPhone"]

        for function_name in instant_function_names:
         
            try:
                function = globals()[function_name]
                if function_name == "process_inquiry_data":
                    tags = [
                        ("InquiryRequestInfo.FamilyDetails", "AdditionalNameInfo", "additionaldetails"),
                        ("InquiryRequestInfo.InquiryAddresses.InquiryAddress",),
                        ("InquiryRequestInfo.InquiryPhones.InquiryPhone",),
                        ("InquiryRequestInfo.InquiryCommonAccountDetails.InquiryAccount",)
                    ]

                    # Iterate over each set of tags and call the function
                    for tag_args in tags:
                        df_result = process_inquiry_data(df_equifax, *tag_args, drop_cols=["_seq"])
                        if df_result is not None:
                            df_result.cache()
                            df_result = df_result.fillna('').dropDuplicates().dropna(how='all')
                            
                            details = "_".join([arg.split('.')[1] for arg in tag_args if '.' in arg])
                            
                            new_table_name = "equifax_" + details
                            source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, object_name, load_to_date, load_type, desti_path)
                         
                            source_data_df.write.format("delta").mode("append").saveAsTable(new_table_name)
                        else:
                            pass
                            logger(logger_level_info, f"Operation doesn't have required columns.", execution_log_list, filename)
                else:
                    df_result = function(df_equifax)
                    if df_result is not None:
                        df_result.cache()
                        df_result=df_result.fillna('').dropDuplicates().dropna(how='all')
                        df_result.display()
                        new_table_name = "equifax_" + function_name
                        source_data_df =  add_meta_data_into_source_df(df_result, exec_log_id, pipeline_run_id, column_to_exclude_frm_scd, dest_save_type, object_name, load_to_date, load_type, desti_path)
                        
                        source_data_df.write.format("delta").mode("append").saveAsTable(new_table_name)
                    else:
                        pass
                        logger(logger_level_info, f"Operation doesn't have required columns.", execution_log_list, filename)
            except Exception as e:
                pass
                logger(logger_level_error, f"Error occurred during: {e}", execution_log_list, filename)
    except Exception as e:
        pass
        logger(logger_level_error, f"Error occurred during execution: {e}", execution_log_list, filename)

