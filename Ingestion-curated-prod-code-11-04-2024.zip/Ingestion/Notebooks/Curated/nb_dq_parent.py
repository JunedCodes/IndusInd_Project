# Databricks notebook source
# Declaring the notebook name
filename = 'nb_dq_parent.dbc'

# COMMAND ----------

# This is the parent Data Quality Framework function, where for each object_name or table name this function would be called. 
# The function will check what are the dq rules configured for that table and call each and every dq rule individually.
# The dq detailed report would be consolidated and appended to the dq_detailed_report delat table in edp_datasharing_layer.bfil catalog schema
# Also updates the metadata columns of source data (incremental data) i.e.ETL_DQ_FINAL_STATUS & ETL_DQ_ERROR with required values 

def data_quality_framework(synapse_jdbc_url, source_data_df, object_name, business_key, load_to_date, pipeline_run_id, object_source, src_object_id, column_to_exclude_frm_scd, adb_dq_dest_url): 

    # Check if it's a list
    if not isinstance(business_key, list):
        # If it's not a list, convert it into a list
        business_key = [business_key]

    try:
        # To get query result from synapse 
        dq_rules_config_df = get_query_result_from_synapse(synapse_jdbc_url, synapse_schema_name, dq_rules_config_table_name, dq_rule_config_column_list)

        # Get defined rules for each table from config_table
        dq_rules_config_df = dq_rules_config_df.filter((lower(col("table_name")) == object_name) & (lower(col("source_system")) == object_source) & (col("dq_enable_flag").cast("integer") == 1))
        logger(logger_level_info, f"Fetching DQ rules configuration data for table {object_name} has been completed.", execution_log_list, filename)

        # Checking is data frame is empty or not
        if dq_rules_config_df.isEmpty():
            # Call the logger function with a log level and message
            logger(logger_level_info, f"The table {object_name} is not configured for DQ check; skipping it.",execution_log_list, filename)
            return source_data_df

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"An error occurred while retrieving data from dq_rules_config.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An error occurred while retrieving data from dq_rules_config.", e)

    rule_params = dq_rules_config_df.select('source_system', 'table_name', 'dq_name', 'dq_rule_parameters').toPandas().to_dict('records')

    # Define a dictionary that maps each rule name to its corresponding function and parameter names
    rule_params_dict = {
        "DQ_MOBILE_MISMATCH_CHECK": {
            "function": dq_mobile_length_check
        },
        "DQ_INVALID_DATE_CHECK": {
            "function": dq_incorrect_date
        },
        "DQ_KYC_NUMBER_LENGTH_CHECK": {
            "function": dq_kyc_number_length_check
        },
        "DQ_LENGTH_CHECK": {
            "function": dq_length_check
        },
        "DQ_AMOUNT_CONSISTENCY_CHECK": {
            "function": dq_amount_consistency_check
        },
        "DQ_IS_CLOSED_DATE_MANDATORY_CHECK": {
            "function": dq_is_closed_date_mandatory_check
        },
        "DQ_ALLOWED_VALUES_CHECK": {
            "function": dq_allowed_values_check
        },
        "DQ_DATE_BETWEEN_CHECK": {
            "function": dq_date_between_check
        },
        "DQ_DOB_CHECK": {
            "function": dq_dob_check
        },
        "DQ_NULL_AND_BLANK_CHECK": {
            "function": dq_null_and_blank_check
        },
        "DQ_PINCODE_CHECK": {
            "function": dq_pincode_check
        },
        "DQ_PATTERN_CHECK": {
            "function": dq_pattern_check
        },
        "DQ_DATE_RELATION_CHECK": {
            "function": dq_date_relation_check
        },
        "DQ_VALUE_RELATION_CHECK": {
            "function": dq_value_relation_check
        },
        "DQ_CORRESPONDING_VALUE_CHECK": {
            "function": dq_corresponding_value_check
        },
        "DQ_AADHAR_CHECK": {
            "function": dq_aadhar_check
        } 
    }

    try:
        # Initialize detailed_report outside the loop  
        detailed_report = None

        # Loop through each rule parameter
        for row in rule_params:
            rule_name = row["dq_name"]

            try:
                rule_function = rule_params_dict.get(rule_name, {}).get("function")
                if rule_function:
                    source_row_count = source_data_df.count()
                    logger(logger_level_info, f"The DataFrame count before DQ for {row['dq_name']} and for {row['dq_rule_parameters']} for the table: {object_name} is {source_row_count}", execution_log_list, filename)

                    # Pass source_data_df
                    source_data_df, detailed_report_df = rule_function(source_data_df, row["source_system"], row["table_name"], row["dq_name"], row['dq_rule_parameters'], business_key, load_to_date, column_to_exclude_frm_scd)

                    source_row_count = source_data_df.count()
                    logger(logger_level_info, f"The DataFrame count after DQ for {row['dq_name']} and for {row['dq_rule_parameters']} for the table: {object_name} is {source_row_count}", execution_log_list, filename)

                    # If detailed_report is None, initialize it with detailed_report_df
                    if detailed_report is None:
                        detailed_report = detailed_report_df
                    else:
                        try:
                            # Append detailed_report_df to detailed_report
                            logger(logger_level_info, f"for {row['dq_name']} and for {row['dq_rule_parameters']} for the table: {object_name} before union", execution_log_list, filename)
                            detailed_report = detailed_report.unionAll(detailed_report_df)
                        except Exception as e:
                            # Call the logger function with a log level and message
                            logger(logger_level_error, f"An error occurred in dq detailed report for column {row['dq_name']} for {row['dq_rule_parameters']} for table: {object_name}.", execution_log_list, filename)
                            print(*execution_log_list, sep='\n')
                            raise Exception(f"An error occurred in dq detailed report for column {row['dq_name']} for {row['dq_rule_parameters']} the for table: {object_name}.", e)
                            
            except Exception as e:
                # Call the logger function with a log level and message
                logger(logger_level_error, f"An error occurred while calling the DQ check function for table: {object_name}.", execution_log_list, filename)
                print(*execution_log_list,sep='\n')
                raise Exception(f"An error occurred while calling the DQ check function for table: {object_name}.", e)
        
        try:
            if detailed_report is None:
                logger(logger_level_info, f"All DQ detailed reports are empty for table: {object_name}.", execution_log_list, filename)
                return source_data_df
            
            else:
                # Loading DQ report as delta table for unity catlog
                detailed_report.write.format("delta").mode("append").option("mergeSchema", "true").option("path", adb_dq_dest_url).saveAsTable(f"{adb_datasharing_catlog_schema}.{dq_detailed_report_table_name}")
                logger(logger_level_info, f"All DQ detailed reports have been created in the ADLS path for table: {object_name}.", execution_log_list, filename)
        except Exception as e:
            # Call the logger function with a log level and message
            logger(logger_level_error, f"Facing an issue while saving the DQ detailed report into a Delta table in ADLS for table: {object_name}.", execution_log_list, filename)
            print(*execution_log_list,sep='\n')
            raise Exception(f"Facing an issue while saving the DQ detailed report into a Delta table in ADLS for table: {object_name}.", e)

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"The error occured while calling dq function for table: {object_name}.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"The error occured while calling dq function for table: {object_name}.", e)

    logger(logger_level_info, f"All executions of the assigned DQ rule have been completed for the table: {object_name}.", execution_log_list, filename)

    if detailed_report is not None:
        try:
            # Create the DQ_ERROR_2 column by concatenating DQ_NAME and DQ_COLUMN_NAME and column DQ_FINAL_STATUS_2
            dq_detailed_report = detailed_report.groupBy('PRIMARY_KEY_VALUE').agg(
                collect_list(concat(lit('"'), detailed_report['DQ_NAME'], lit('" : "'), detailed_report['DQ_COLUMN_NAME'], lit('"'))).alias('DQ_ERROR_2_list'),  
                lit('0').alias('DQ_FINAL_STATUS_2') 
            ).withColumn(
                'DQ_ERROR_2',
                concat(lit('{'), concat_ws(', ', 'DQ_ERROR_2_list'), lit('}')).cast('string')
            ).drop('DQ_ERROR_2_list')
            
            dq_detailed_report_count = dq_detailed_report.count()
            logger(logger_level_info, f"The dq report counts after the agg of the ETL_DQ_ERROR group by PRIMARY_KEY_VALUE for the table: {object_name} is {dq_detailed_report_count}", execution_log_list, filename)

            if isinstance(business_key, list):

                # Initialize the join condition
                join_condition = None

                # Parse the PRIMARY_KEY_VALUE column assuming it's a string with pipe-separated values with spaces
                parsed_primary_key = split(col("PRIMARY_KEY_VALUE"), " \| ")

                # Loop through the columns in business_key to construct the join condition
                for column in business_key:
                    # Construct the join condition for the current column
                    condition = col(column) == parsed_primary_key[business_key.index(column)]
                    
                    # Update the join_condition based on whether it's the first condition or not
                    if join_condition is None:
                        join_condition = condition
                    else:
                        join_condition = join_condition & condition

                # Perform the left join
                joined_df = source_data_df.join(dq_detailed_report, join_condition, "left")

            else :

                # Join the DataFrames
                joined_df = source_data_df.join(dq_detailed_report, col(business_key) == col("PRIMARY_KEY_VALUE"), "left")

            joined_df_count = joined_df.count()
            logger(logger_level_info, f"The joined_df_count after window for the table: {object_name} is {joined_df_count}", execution_log_list, filename)

            source_data_df = joined_df.withColumn(
                "ETL_DQ_ERROR", 
                when(
                    col("DQ_ERROR_2").isNotNull(), col("DQ_ERROR_2")
                ).otherwise(None)
            ).withColumn(
                "ETL_DQ_FINAL_STATUS",
                when(col("DQ_ERROR_2").isNotNull(), col("DQ_FINAL_STATUS_2")).otherwise(col("ETL_DQ_FINAL_STATUS"))
            ).drop("PRIMARY_KEY_VALUE", "DQ_ERROR_2", "DQ_FINAL_STATUS_2")
            
            logger(logger_level_info, f"The addition of the ETL_DQ_ERROR and the update of the ETL_DQ_FINAL_STATUS column have been completed for the table: {object_name}.", execution_log_list, filename)
            
        except Exception as e:
            # Call the logger function with a log level and message
            logger(logger_level_error, f"An error occurred while executing an operation on the dq_detailed_report table.", execution_log_list, filename)
            print(*execution_log_list,sep='\n')
            raise Exception(f"An error occurred while executing an operation on the 'dq_detailed_report' table.", e)

    return source_data_df