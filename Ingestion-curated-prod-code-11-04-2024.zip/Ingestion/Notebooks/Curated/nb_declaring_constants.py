# Databricks notebook source
# Defining start time of notebook execution 
start_timestamp = datetime.now(pytz.timezone('Asia/Kolkata'))

# Defining constants 
logger_level_debug = "DEBUG"
logger_level_info = "INFO"
logger_level_warn = "WARN"
logger_level_error = "ERROR"
log_error_success = "NO_ERROR"
log_error_failure = "ERROR"
log_status_failure = "FAILED"
log_status_success = "SUCCESS"

# For synapse inputs
log_table_name = "pl_exec_log"
config_table_name = "pl_src_sys_detail"
log_column_list = ["exec_log_id"]
config_column_list = ["desti_path"]

# Adjust timestamp format for comparison
timestamp_format = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"

# counting total rows in dataframe
source_row_count = 0

# counting total rows in existing table
destination_row_count = 0

#lookup varaible for comparisng operator
lookup_for_comparison_operator={
	"ge" : "greater than or equals to",
	"gt" : "greater than ",
	"le" : "less than or equals to",
	"lt" : "less than",
	"eq" : "equals to",
	"ne" : "not equals to"
}

# adls constants
adls_storage_account_key = "IBL-ADLS-GEN2-ACCOUNT-KEY"
adb_secret_scope_name = "AKV_secret_scope"

synapse_schema_name = "bfil_meta"

# DQ constants
dq_rules_config_table_name = "dq_rule_config"
dq_rule_config_column_list = ["source_system", "table_name", "dq_name", "dq_rule_parameters", "dq_enable_flag"]

dq_detailed_report_table_name = "DQ_DETAILED_REPORT"  

# For execution log of pipeline.
execution_log_list = []

# COMMAND ----------

# adls constants
adls_storage_account_key = "xgwRZyfEKGPCXvbtlfdfoyWzJ7Jk+XSb7Ckof7ODS63p2JoE+5wus1O7bJho2rtF56A1DFbU5+M/+AStUnWtFw=="
crif_tag="INDV-REPORT"

#cb constant
cbpreaaproved='CB_PreApproved'
onetimeload="ONE TIME LOAD"
transactional="TRANSACTIONAL"
instantcblogs="INSTANTCBLOGS"
reportmart="Report_Mart"