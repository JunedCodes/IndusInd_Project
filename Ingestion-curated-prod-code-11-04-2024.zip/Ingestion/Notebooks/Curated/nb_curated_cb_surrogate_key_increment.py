# Databricks notebook source
def add_sk_column(df, max_sk_value=None):
    if 'SK' not in df.columns:
        if max_sk_value is None:
            # Check if the table exists
            table_exists = spark.sql("SHOW TABLES LIKE 'crif_header'").count() > 0
            if table_exists:
                # Fetch maximum 'SK' value from the header table
                max_sk_value = spark.sql("SELECT MAX(SK) AS max_sk FROM crif_instant_header").collect()[0]["max_sk"]
             
            else:
                # If table does not exist, set max_sk_value to 0
                max_sk_value = 1
       
        # Generate row numbers starting from the maximum 'SK' value + 1, and subtract 1
        df = df.withColumn("SK", F.row_number().over(Window.orderBy(F.monotonically_increasing_id())) + max_sk_value - 1)
    return df




# COMMAND ----------


def add_sk_column_equifax(df, max_sk_value=None):
    if 'SK' not in df.columns:
        if max_sk_value is None:
            # Check if the table exists
            table_exists = spark.sql("SHOW TABLES LIKE 'equifax_InquiryResponseHeader'").count() > 0
            if table_exists:
                # Fetch maximum 'SK' value from the header table
                max_sk_value = spark.sql("SELECT MAX(SK) AS max_sk FROM crif_instant_header").collect()[0]["max_sk"]
             
            else:
                # If table does not exist, set max_sk_value to 0
                max_sk_value = 1
       
        # Generate row numbers starting from the maximum 'SK' value + 1, and subtract 1
        df = df.withColumn("SK", F.row_number().over(Window.orderBy(F.monotonically_increasing_id())) + max_sk_value - 1)
    return df