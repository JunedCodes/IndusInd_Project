# Databricks notebook source
filename='nb_curated_cb_crif_functions.dbc'
def header(df_crif):
    try:
        if df_crif:
            df_header=df_crif.select("SK",'HEADER.*')
            return df_header
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in header : {e} " ,execution_log_list,filename)
        return None

# COMMAND ----------

def request(df_crif):
    try:
        if df_crif is not None:
            df_request = df_crif.select("SK",'REQUEST.*').drop("IDS", "ADDRESSES", "PHONES", "EMAILS")
            return df_request
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in request : {e} " ,execution_log_list,filename)
        pass
        return None

# COMMAND ----------

#contact
def contact(df_crif):
    try:
        combined_df=None
        if df_crif is not None:
           
            indv_responses_tags = df_crif.select("SK", explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            
            grp_responses_tags = df_crif.select("SK", explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))
            fields = ['PHONES', 'ADDRESSES', 'EMAILS']
            for response_tags in [indv_responses_tags, grp_responses_tags]:
                for field in fields:
                    try:
                        # Extract the specified field and explode it
                        contact_df = response_tags.select("SK", 
                            explode_outer(
                                col(f"Indv-responses.{field}.{'PHONE' if field == 'PHONES' else 'ADDRESS' if field == 'ADDRESSES' else 'EMAIL'}")
                            ).alias("Value"))
                        
                        # Add a Type column
                        contact_df = contact_df.withColumn("Type", lit("Phone" if field == "PHONES" else "Address" if field == "ADDRESSES" else "Email"))

                        if combined_df is None:
                            combined_df = contact_df
                        else:
                            combined_df = combined_df.union(contact_df)
                    except:
                        pass
            return combined_df
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in responses: {e} ",execution_log_list,filename)
        pass
        return None

# COMMAND ----------

#Relation
def relation(df_crif):
    try:
        if df_crif is not None: 
            indv_responses_tags = df_crif.select("SK",explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            grp_responses_tags = df_crif.select("SK",explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))

            df_relation_indv = indv_responses_tags.select("SK",col("Indv-responses.RELATIONS.RELATION")).select("SK",explode("Relation").alias("relation")).select("SK","relation.*")
            df_relation_grp = grp_responses_tags.select("SK",col("GRP-responses.RELATIONS.RELATION")).select("SK",explode("Relation").alias("relation")).select("SK","relation.*") 
            try:
                df_relation = df_relation_indv.union(df_relation_grp)
            except: 
                if df_relation_indv is not None:
                    df_relation = df_relation_indv
                elif df_relation_grp is not None:
                    df_relation = df_relation_grp
                else:
                    df_relation = None

            return df_relation

        else:           
            pass
            logger(logger_level_info, "Dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in relation : {e} " ,execution_log_list,filename)
        pass


# COMMAND ----------

#Alerts
def alert(df_crif):
    try:
        if df_crif is not None:
            df_alerts = df_crif.select("SK",'ALERTS.ALERT.*')
            return df_alerts
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in alerts : {e} " ,execution_log_list,filename)
        return None
        

# COMMAND ----------

#Status details
def statusdetails(df_crif):
    try:
        if df_crif is not None:
            df_statusdetails=df_crif.select("SK",explode("STATUS-DETAILS.STATUS").alias("status"))
            df_statusdetails = df_statusdetails.select("SK",
                col("status.ERRORS.ERROR.ERROR-DESCRIPTION").alias("ERROR"),
                col("status.OPTION").alias("OPTION"),
                col("status.OPTION-STATUS").alias("OPTION-STATUS")
            ) 
            return df_statusdetails
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in statusdetails : {e} " ,execution_log_list,filename)
        return None

# COMMAND ----------

#inquiryhistory
def inquiryhistory(df_crif):
    try:
        if df_crif is not None:
            df_inquiryhistory=df_crif.select("SK",explode("INQUIRY-HISTORY.HISTORY").alias("history")).select("history.*")
            return df_inquiryhistory
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in inquiryhistory : {e} " ,execution_log_list,filename)
        return None
        

# COMMAND ----------

#Groupdetails
def groupdetails(df_crif):
    try:
        if df_crif is not None:
            grp_responses_tags = df_crif.select("SK",explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))
            group_details_grp = grp_responses_tags.select("SK",col("GRP-responses.GROUP-DETAILS.*"))
            indv_responses_tags = df_crif.select("SK",explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            group_details_indv = indv_responses_tags.select("SK",col("Indv-responses.GROUP-DETAILS.*"))
            combined_group_details = group_details_grp.union(group_details_indv)
            return combined_group_details
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in group details: {e} " ,execution_log_list,filename)
        return None
    


# COMMAND ----------

#Variation
def variation(df_crif):
    try:
        variation_df = df_crif.select("SK", "PERSONAL-INFO-VARIATION.*")
        if variation_df is not None:
            def find_nested_types(schema, prefix=""):
                struct_cols = []
                array_cols = []
                string_cols = []

                for field in schema.fields:
                    col_name = prefix + field.name

                    if isinstance(field.dataType, StructType):
                        struct_cols.append(col_name)
                        # Check if the struct has nested fields
                        nested_field = field.dataType
                        if len(nested_field.fields) > 0:
                            if isinstance(nested_field.fields[0].dataType, ArrayType):
                                array_cols.append(col_name)
                            elif isinstance(nested_field.fields[0].dataType, StructType):
                                struct_cols.append(col_name)
                            else:
                                string_cols.append(col_name)

                    elif isinstance(field.dataType, ArrayType) and isinstance(field.dataType.elementType, StructType):
                        array_cols.append(col_name)
                    elif isinstance(field.dataType, ArrayType):
                        array_cols.append(col_name)
                    elif isinstance(field.dataType, StringType):
                        string_cols.append(col_name)

                return struct_cols, array_cols, string_cols

            struct_cols, array_cols, string_cols = find_nested_types(variation_df.schema)

            merged_df = spark.createDataFrame([], schema="`SK` STRING, `REPORTED-DATE` STRING, `VALUE` STRING, `TYPE` STRING")

            for col_name in array_cols:
                sub_df = variation_df.select("SK", explode(col(f"{col_name}.VARIATION"))).select("SK", col("col.*")).withColumn("TYPE", lit(col_name))
                merged_df = merged_df.union(sub_df)

            remaining_struct_cols = [col_name for col_name in struct_cols if col_name not in array_cols]
            for col_name in remaining_struct_cols:
                sub_df = variation_df.select("SK", f"{col_name}.VARIATION.*").withColumn("TYPE", lit(col_name))
                merged_df = merged_df.union(sub_df).dropDuplicates()

            return merged_df

        else:
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list, filename)
    except Exception as e:
        logger(logger_level_info, f"Error in variations: {e} ", execution_log_list, filename)
        return None



# COMMAND ----------

#loandetails
def loan_details(df_crif):
    try:
        if df_crif is not None:
            indv_responses_tags = df_crif.select("SK",explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-resposnes"))
            loandetails_indv=indv_responses_tags.select("SK",col("Indv-resposnes.LOAN-DETAIL.*"))
            grp_responses_tags= df_crif.select("SK",explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-resposnes"))
            loandetails_grp=grp_responses_tags.select("SK",col("GRP-resposnes.LOAN-DETAIL.*"))
            combined_df=loandetails_indv.unionByName(loandetails_grp,allowMissingColumns=True)
            df_loandetails_responses= df_crif.select("SK", explode("RESPONSES.RESPONSE.LOAN-DETAILS").alias("Loan-details")).select("SK","Loan-details.*").drop("LINKED-ACCOUNTS","SECURITY-DETAILS")
            df_loandetail=combined_df.unionByName(df_loandetails_responses,allowMissingColumns=True)
            return df_loandetail
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in loandetaisl: {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

# ##Ids
def ids(df_crif):
    try:
        if df_crif is not None:
            indv_responses_tags = df_crif.select("SK",explode_outer("INDV-RESPONSES.INDV-RESPONSE-LIST.INDV-RESPONSE").alias("Indv-responses"))
            grp_responses_tags = df_crif.select("SK",explode_outer("GRP-RESPONSES.GRP-RESPONSE-LIST.GRP-RESPONSE").alias("GRP-responses"))

            ids_indv = indv_responses_tags.select("SK", col("Indv-responses.IDS.ID").alias("ids")).select("SK", explode("ids").alias("id")).select("SK", col("id.*")) 
            ids_grp = grp_responses_tags.select("SK", col("GRP-responses.IDS.ID").alias("ids")).select("SK", explode("ids").alias("id")).select("SK", col("id.*"))

            if ids_grp and ids_indv is not None:
                combined_ids = ids_grp.union(ids_indv)

            elif ids_indv is not None:
                combined_ids = ids_indv
            elif ids_grp is not None:
                combined_ids = ids_grp
            else:
                combined_ids = None

            return combined_ids
        else:           
            pass
            logger(logger_level_info, "Dataframe has no data ", execution_log_list,filename)  
    except Exception as e:
        logger(logger_level_info, f"Error in Ids: {e} " ,execution_log_list,filename)
        return None
    

# COMMAND ----------

#Response_list
def responselist(df_crif):
    try:
        if df_crif is not None:
            df_respoonselist_indv = df_crif.select("SK", col("INDV-RESPONSES.INDV-RESPONSE-LIST.*")) \
                .select("SK", explode("INDV-RESPONSE").alias("indv-response")) \
                .select("SK", "indv-response.*") \
                .withColumn("List-Type", lit("INDV-RESPONSE")) \
                .drop("ADDRESSES", "PHONES", "GROUP-DETAILS", "IDS", "LOAN-DETAIL", "RELATIONS") \

            df_respoonselist_grp= df_crif.select("SK", col("GRP-RESPONSES.GRP-RESPONSE-LIST.*")) \
                .select("SK", explode("GRP-RESPONSE").alias("grp-response")) \
                .select("SK", "grp-response.*") \
                .withColumn("List-Type", lit("GRP-RESPONSE")) \
                .drop("ADDRESSES", "PHONES", "GROUP-DETAILS", "IDS", "LOAN-DETAIL", "RELATIONS") \
            
            if df_respoonselist_grp is not None and df_respoonselist_indv is not None:
                df_response_list = df_respoonselist_indv.unionByName(df_respoonselist_grp, allowMissingColumns=True)
            elif df_respoonselist_grp is not None or df_respoonselist_indv is None :
                df_response_list = df_respoonselist_grp
            elif df_respoonselist_indv is not None or df_respoonselist_grp is None:
                df_response_list = df_respoonselist_indv
            else:
                df_response_list = None

            return df_response_list
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in responselist: {e} " ,execution_log_list,filename)
        return None
    

# COMMAND ----------

#Scores
def score(df_crif):
    try:
        if df_crif is not None:
            df_score=df_crif.select("SK","SCORES.SCORE.*")
            return df_score
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in scores: {e} " ,execution_log_list,filename)
        return None
    



# COMMAND ----------

#Secondary_matches
def secondary_matches(df_crif):
    try:
        if df_crif is not None:
            df_secmatches=df_crif.select("SK","SECONDARY-MATCHES")
            return df_secmatches
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in secondary_matches: {e} " ,execution_log_list,filename)
        return None



# COMMAND ----------


#accountsumamry
def account_Summary(df_crif):
    try:
        if df_crif is not None:
            df_accountsummary = df_crif.select(
            "SK",
            "ACCOUNTS-SUMMARY.DERIVED-ATTRIBUTES.*",
            "ACCOUNTS-SUMMARY.PRIMARY-ACCOUNTS-SUMMARY.*",
            "ACCOUNTS-SUMMARY.SECONDARY-ACCOUNTS-SUMMARY.*"
        )
            return df_accountsummary
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in account_summary: {e} " ,execution_log_list,filename)
        return None
    


# COMMAND ----------

#Securitydetails
def securitydetails(df_crif):
    try:
        if df_crif is not None:
            secdetails = df_crif.select("SK", explode("RESPONSES.RESPONSE.LOAN-DETAILS.SECURITY-DETAILS.SECURITY-DETAIL").alias("Security_details")).select("SK", explode("Security_details").alias("Security_detail_new")).select("SK","Security_detail_new.*") 
            return secdetails
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in securitydetails: {e} " ,execution_log_list,filename)
        return None
    


# COMMAND ----------

#linkedaccounts
def linked_accounts(df_crif):
    try:
        if df_crif is not None:
            df_linkedacc= df_crif.select("SK", explode("RESPONSES.RESPONSE.LOAN-DETAILS.LINKED-ACCOUNTS.ACCOUNT-DETAILS").alias("Linkedaccounts")).select("SK","Linkedaccounts.*")
            return df_linkedacc
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in linkedaccounts: {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#response     
def response(df_crif):
    try:
        if df_crif is not None:
            df_responses_grp = df_crif.select("SK", "GRP-RESPONSES.SUMMARY", "GRP-RESPONSES.PRIMARY-SUMMARY", "GRP-RESPONSES.SECONDARY-SUMMARY")
            df_responses_indv = df_crif.select("SK", "INDV-RESPONSES.SUMMARY", "INDV-RESPONSES.PRIMARY-SUMMARY", "INDV-RESPONSES.SECONDARY-SUMMARY")

            selcolList = ["SECONDARY-SUMMARY", "PRIMARY-SUMMARY", "SUMMARY"]
            for colname in selcolList:
                tempL = df_responses_grp.select(f"{colname}.*").columns
                for col_name in tempL:
                    prefix = "Sec_" if colname == selcolList[0] else "Pri_" if colname == selcolList[1] else "Sum_"
                    df_responses_grp = df_responses_grp.select(f"{colname}.*", "*")
                    df_responses_grp = df_responses_grp.withColumnRenamed(col_name, f"{prefix}{col_name}").drop(*tempL)
            df_responses_grp = df_responses_grp.withColumn("Response-Type", lit("GRP-RESPONSE"))
            for colname in selcolList:
                tempL = df_responses_indv.select(f"{colname}.*").columns
                for col_name in tempL:
                    prefix = "Sec_" if colname == selcolList[0] else "Pri_" if colname == selcolList[1] else "Sum_"
                    df_responses_indv = df_responses_indv.select(f"{colname}.*", "*")
                    df_responses_indv = df_responses_indv.withColumnRenamed(col_name, f"{prefix}{col_name}").drop(*tempL)

            df_responses_indv = df_responses_indv.withColumn("Response-Type", lit("Indv-RESPONSE"))

            df_response = df_responses_indv.unionByName(df_responses_grp, allowMissingColumns=True).drop("SUMMARY", "PRIMARY-SUMMARY", "SECONDARY-SUMMARY")

            return df_response
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in responses: {e} " ,execution_log_list,filename)
        return None


# COMMAND ----------

#comment
def comment(df_crif):
    try:
        if df_crif is not None:
            if "Comment" in df_crif.columns:
                df_comment = df_crif.select("SK","COMMENT.*")
            else:
                df_comment = None
            return df_comment
        else:           
            pass
            logger(logger_level_info, "dataframe has no data ", execution_log_list,filename)
    except Exception as e:
        logger(logger_level_info, f"Error in comment: {e} " ,execution_log_list,filename)
        return None
