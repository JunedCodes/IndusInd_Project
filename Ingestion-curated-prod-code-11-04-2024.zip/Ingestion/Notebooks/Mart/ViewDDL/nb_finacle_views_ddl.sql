-- Databricks notebook source
use edp_bfil_prod.finacle

-- COMMAND ----------

/* Aadhar Seeding Query */   
CREATE OR REPLACE VIEW IBL_Aadhar_Seeding_VW AS
SELECT cif_id AS CIFID,
			foracid AS FORACID,
			schm_code AS SCHM_CODE,
			referencenumber AS REFERENCENUMBER,
			STATUS AS STATUS,
			(CASE  WHEN STATUS IS NULL THEN 'NO'
			ELSE 'YES' END) AS ADHAR_SEEDING_STATUS
From edp_curated_prod.finacle.gam g
JOIN edp_curated_prod.finacle.entitydocument e ON g.cif_id = e.orgkey
WHERE g.schm_code IN ('CABFI', 'CABFT', 'SBMIC','RDMIC','RDMIS','TRMIC','TRMIS')
AND doccode LIKE '%UID%'
AND referencenumber IS NOT NULL

-- COMMAND ----------

/* Balances Query */ 
CREATE OR REPLACE VIEW IBL_Balances_Report_VW AS
SELECT	foracid as FORACID,
			acct_name AS ACCT_NAME,
			schm_code AS SCHM_CODE,
			clr_bal_amt AS BAL_YESTERDAY,
			acct_cls_flg AS ACCT_CLS_FLG
FROM edp_curated_prod.finacle.Gam
Left Join edp_curated_prod.finacle.Gac On edp_curated_prod.finacle.gam.acid=gac.acid
WHERE Acct_Cls_Flg = 'N' AND Entity_Cre_Flg = 'Y' AND Del_Flg = 'N'
and (Schm_Type='CAA' Or Schm_Type='SBA' Or Schm_Type='TDA')
and (schm_code IN ('CABFI', 'CABFT', 'SBMIC','RDMIC','RDMIS','TRMIC','TRMIS')
OR foracid IN ('201002335583','201002335682','201002335569','201002335675','201002335576','201001788670'))

-- COMMAND ----------

/* Dormat Query */ 
CREATE OR REPLACE VIEW IBL_Dormat_Report_VW AS
SELECT	g.foracid as FORACID, 
			g.schm_code as SCHM_CODE,
			ACCT_STATUS as ACCT_STATUS, 
			CAST(ACCT_STATUS_DATE AS DATE) as ACCT_STATUS_DATE ,
           eab_tran_date.tran_date_bal AS EAB_BAL_SYSDATE_1,
           (select CAST(db_stat_date AS DATE)from edp_curated_prod.finacle.gct) as REPORT_GENERATION_DATE
FROM edp_curated_prod.finacle.gam g
JOIN edp_curated_prod.finacle.smt s ON g.acid = s.acid
LEFT JOIN (SELECT acid, tran_date_bal 
				 FROM edp_curated_prod.finacle.eab
				WHERE eod_date <= DATE_SUB(CURRENT_DATE(), 1) 
				AND end_eod_date >= DATE_SUB(CURRENT_DATE(), 1)) AS eab_tran_date ON eab_tran_date.acid = g.acid
WHERE s.ACCT_STATUS IN ('D', 'I')
and g.schm_code IN ('CABFI', 'CABFT', 'SBMIC');

-- COMMAND ----------

/* FD & RD Matured & Pre-Closure Query */
CREATE OR REPLACE VIEW IBL_FD_AND_RD_MATURED_AND_PRECLOSER_VW AS
SELECT	gam.foracid as FORACID, 
			gam.acct_name as ACCT_NAME,
			CAST(tam.open_effective_date AS DATE) as ACCT_OPN_DATE,
			tam.deposit_amount as DEP_AMT, 
			gam_foracid.foracid AS  SBACCOUNT,
			(tam.cumulative_instl_paid / tam.deposit_amount) as NOOFINSTALLMENT,
			tam.cumulative_instl_paid as CUMULATIVE_INSTL_PAID, 
			tam.cumulative_int_credited,
			tph.part_close_amt AS PRECLOSEAMT,
			gam.acct_cls_flg AS  ACCT_CLS_FLG,
      COALESCE(CAST(tph.part_close_date AS DATE), CAST(tam.cls_value_date AS DATE)) AS CLOSEDATE,
			(Case when gam.acct_cls_date < tam.maturity_date and tph.CLOSURE_TYPE = 'P'Then 'Pre-Closure' Else 'Matured' End) As  CLOSURESTATUS
FROM edp_curated_prod.finacle.tam
JOIN	edp_curated_prod.finacle.gam ON gam.acid = tam.acid
LEFT JOIN edp_curated_prod.finacle.gam AS gam_foracid ON gam_foracid.acid = tam.repayment_acid
Left Join edp_curated_prod.finacle.tph ON tph.acid = gam.acid and tph.CLOSURE_TYPE = 'P' 
WHERE	gam.schm_code IN ('TRMIC','TRMIS','RDMIC','RDMIS')
and gam.acct_cls_flg  ='Y'

-- COMMAND ----------

--FDMIC_ACCT_DUMP_NEW
CREATE OR REPLACE VIEW IBL_FDMIC_ACCT_DUMP_VW AS
Select 	'SKS' AS PROMO_CODE,
			schm_code AS SCHM_CODE,
			gam.sol_id AS BRANCH_CODE,
			s.sol_desc AS BRANCH_NAME,
			cif_id AS CUSTOMER_NO,
			foracid AS FD_AC,
			acct_name AS CUSTOMER_NAME,
			gac2.free_code_10 AS C5_CODE,
			gam.rcre_user_id AS CREATED_BY,
			substring(gender, 1, 1) AS GENDER,
			CAST(cust_dob AS DATE) AS DATE_OF_BIRTH,
			c.localetext AS CUSTOMER_CATEGORY,
			a.FATHER_HUSBand_NAME AS FATHER_HUSBAND_NAME,
			rt.REF_DESC AS STATE,
			rt3.REF_DESC AS CITY,
			ad.zip AS ZIP,
			Cast(acct_opn_date As Date) As ACCT_OPN_DATE,
			deposit_period_mths AS DEP_PERIOD_MONTH,
			deposit_period_days AS DEP_PERIOD_DAYS,
			eit.INTEREST_RATE AS INTEREST_RATE,
			reno.renewal_option AS RENEWAL_TYPE,
			auto_renewal_flg AS AUTO_RENEWAL_INST,
			close_on_maturity_flg AS CLOSE_ON_MATURITY_FLG,
			maturity_date AS DATE_OF_MATURITY,
			CLR_BAL_AMT AS CLR_BAL_AMT,
			deposit_amount AS FD_BOOKING_AMT
From edp_curated_prod.finacle.gam
Join edp_curated_prod.finacle.accounts a ON gam.cif_id = a.orgkey
Join edp_curated_prod.finacle.gac ON gam.acid = gac.acid
Join edp_curated_prod.finacle.TAM T ON gam.acid = T.acid
Left Join edp_curated_prod.finacle.sol s ON s.sol_id = gam.sol_id
Left Join edp_curated_prod.finacle.gac gac2 ON gac2.acid = gam.acid
Left Join (Select  localetext,value,ROW_NUMBER() OVER (PARTITION BY value ORDER BY value) AS lcl_txt_rn
				From edp_curated_prod.finacle.categories c
				Join edp_curated_prod.finacle.category_lang cl ON cl.categoryid = c.categoryid
				Where categorytype IN ('CUST_TYPE1', 'CUST_TYPE_DESC')) c ON c.value = a.cust_type and c.lcl_txt_rn = 1
Left Join (Select  state,city,zip,orgkey,ROW_NUMBER() OVER (PARTITION BY orgkey ORDER BY orgkey) AS zip_rn
				From edp_curated_prod.finacle.address 
				Where preferredaddress = 'Y') ad ON ad.orgkey = gam.cif_id and ad.zip_rn = 1
Left Join (Select  REF_DESC,REF_CODE,ROW_NUMBER() OVER (PARTITION BY REF_CODE ORDER BY REF_CODE) AS stt_rn
				From edp_curated_prod.finacle.RCT
				Where RCT.REF_REC_TYPE = '02' and RCT.Bank_id = '01'
				and RCT.del_flg = 'N' ) rt ON rt.REF_CODE = ad.state and rt.stt_rn =1
Left Join (Select  REF_DESC,REF_CODE,ROW_NUMBER() OVER (PARTITION BY REF_CODE ORDER BY REF_CODE) AS ct_rn
				From edp_curated_prod.finacle.RCT
				Where RCT.REF_REC_TYPE = '01' and RCT.Bank_id = '01' and RCT.del_flg = 'N' ) rt3 ON rt3.REF_CODE = ad.city and rt3.ct_rn =1
Left Join edp_curated_prod.finacle.EIT ON eit.entity_id = gam.acid
Left Join edp_curated_prod.finacle.reno ON reno.acid = gam.acid
Where gam.Acct_Cls_Flg ='N' And gam.Entity_Cre_Flg='Y' And gam.Del_Flg='N'
and Schm_Type = 'TDA'
and Schm_code IN ('TRMIC', 'TRMIS')

-- COMMAND ----------


/* Freeze Query */ 
CREATE OR REPLACE VIEW IBL_FREEZE_REPORT_VW AS
select	foracid as FORACID,
			frez_code as FREZ_CODE,
			frez_reason_code as FREZ_REASON_CODE,
			frez_reason_code_2 as FREZ_REASON_CODE2,
			schm_code as SCHM_CODE,
			acct_cls_flg as ACCT_CLS_FLG,
			(select CAST(db_stat_date AS DATE) from edp_curated_prod.finacle.gct) as REPORT_GENERATION_DATE
from edp_curated_prod.finacle.gam 
where schm_code IN ('CABFI', 'CABFT', 'SBMIC')
and frez_code in('D','T','C');

-- COMMAND ----------

/*LIEN REMOVAL REPORT */
CREATE OR REPLACE VIEW IBL_LIEN_REMOVAL_REPORT_VW AS
SELECT	CIF_ID as CIF_ID,
			FORACID as FORACID,
			schm_code as SCHM_CODE,
			a.b2k_type AS B2K_TYPE,
			a.b2k_id AS LIEN_REF_NUM,
			a.LIEN_AMT AS LIEN_AMT,
			a.LIEN_REMARKS AS LIEN_REMARKS,
			a.LIEN_REASON_CODE AS LIEN_REASON_CODE,
			rct.ref_desc as DESCc,
			a.REQUESTED_BY_DESC AS REQUESTED_BY_DESC,
			a.rcre_user_id AS CREATEDBY,
			a.lchg_time AS LCHG_TIME,
			DATE_SUB((SELECT db_stat_date FROM edp_curated_prod.finacle.gct), 1) AS REPORT_DATE
FROM edp_curated_prod.finacle.gam g
JOIN edp_curated_prod.finacle.alt a ON g.acid = a.acid
LEFT JOIN edp_curated_prod.finacle.rct ON  rct.ref_code = a.lien_reason_code AND ref_rec_type = 'BF'
Where g.schm_code IN ('CABFI', 'CABFT', 'SBMIC','RDMIC','RDMIS','TRMIC','TRMIS')
AND g.acct_cls_flg = 'N' AND a.lien_reason_code <> '043'

-- COMMAND ----------



--Lien Report
CREATE OR REPLACE VIEW IBL_LIEN_REPORT_VW AS
SELECT	g.CIF_ID AS CIF_ID, 
			g.FORACID AS FORACID,
			g.schm_code AS SCHM_CODE, 
			a.b2k_type AS B2K_TYPE,
			a.b2k_id AS LIEN_REF_NUM,
			a.LIEN_AMT AS LIEN_AMT, 
			a.LIEN_REMARKS AS LIEN_REMARKS,
			a.LIEN_REASON_CODE AS LIEN_REASON_CODE,
			r.ref_desc AS DESCc,
			a.REQUESTED_BY_DESC AS REQUESTED_BY_DESC,
			a.rcre_user_id AS CREATEDBY,
			a.lchg_time AS LCHG_TIME,
			a.LIEN_START_DATE AS LIEN_START_DATE,
			a.LIEN_EXPIRY_DATE AS LIEN_EXPIRY_DATE,
			DATE_SUB(CAST((SELECT db_stat_date FROM edp_curated_prod.finacle.gct) AS TIMESTAMP), 1) as REPORT_DATE
FROM edp_curated_prod.finacle.gam g
JOIN edp_curated_prod.finacle.alt a ON g.acid = a.acid
LEFT JOIN edp_curated_prod.finacle.rct r ON r.ref_code = a.LIEN_REASON_CODE AND r.ref_rec_type = 'BF'
WHERE g.schm_code IN ('CABFI', 'CABFT', 'SBMIC','RDMIC','RDMIS','TRMIC','TRMIS')
AND g.acct_cls_flg = 'N' AND a.lien_reason_code <> '043';

-- COMMAND ----------



/* SBA_CAA_CLOSED_REPORT */
CREATE OR REPLACE VIEW IBL_SBA_CAA_CLOSED_REPORT_VW AS
SELECT	'SKS' AS PROMO_CODE,
			schm_code AS SCHM_CODE,
			gam.sol_id AS BRANCH_CODE,
			sol.sol_desc AS BRANCH_NAME,
			cif_id AS CUSTOMER_NO,
			foracid AS SB_AC,
			acct_name AS CUSTOMER_NAME,
			gam.acct_cls_date AS ACCT_CLS_DATE,
			ACCT_CLS_REASON_CODE AS ACCT_CLS_REASON_CODE,
			rct.ref_desc AS CLOSURE_REASON,
			gac.free_code_10 AS C5_CODE,
      CAST(acct_opn_date AS DATE) AS ACCT_OPN_DATE
FROM edp_curated_prod.finacle.gam
INNER JOIN edp_curated_prod.finacle.accounts a ON gam.cif_id = a.orgkey
INNER JOIN edp_curated_prod.finacle.gac ON gam.acid = gac.acid
INNER JOIN edp_curated_prod.finacle.smt ON gam.acid = smt.acid
LEFT JOIN edp_curated_prod.finacle.sol ON sol.sol_id = gam.sol_id
LEFT JOIN edp_curated_prod.finacle.rct ON rct.ref_code = smt.ACCT_CLS_REASON_CODE AND rct.ref_rec_type = 'GX'
LEFT JOIN edp_curated_prod.finacle.gac g2 ON g2.acid=gam.acid
WHERE gam.Acct_Cls_Flg = 'Y' AND gam.Entity_Cre_Flg = 'Y'
AND gam.Del_Flg = 'N' 
and gam.Schm_Type In ('CAA','SBA')
And gam.schm_code IN ('SBMIC','CABFI', 'CABFT')

-- COMMAND ----------

/* SBMIC & CAA Account Dump New */ 
CREATE OR REPLACE VIEW IBL_SBMIC_AND_CAA_ACCT_DUMP_VW AS
Select	'SKS' AS PROMO_CODE,
			gam.schm_code AS SCHM_CODE,
			gam.sol_id AS BRANCH_CODE,
			s1.sol_desc AS BRANCH_NAME,
			gam.cif_id AS CUSTOMER_NO,
			gam.foracid AS SB_AC,
			gam.acct_name AS CUSTOMER_NAME,
			gac2.free_code_10 AS C5_CODE,
			gam.rcre_user_id AS CREATED_BY,
			SUBSTR(gender, 1, 1) AS GENDER,
			CAST(cust_dob AS DATE) AS DATE_OF_BIRTH,
			c.localetext AS CUSTOMER_CATEGORY,
			a.FATHER_HUSBand_NAME AS FATHER_HUSBAND_NAME,
			rt.REF_DESC AS STATE,
			rt3.REF_DESC AS CITY,
			ad.zip AS ZIP,
      CAST(acct_opn_date AS DATE) AS ACCT_OPN_DATE,
			smt.acct_status AS ACCT_STATUS,
			CASE WHEN dateuserfield5 IS NULL THEN 'N' ELSE 'Y' END AS RE_KYC_FLAG,
			CAST(dateuserfield5 AS DATE) AS RE_KYC_DATE
From edp_curated_prod.finacle.gam
Join edp_curated_prod.finacle.accounts a ON gam.cif_id = a.orgkey
Join edp_curated_prod.finacle.gac ON gam.acid = gac.acid
Left Join edp_curated_prod.finacle.sol s1 ON s1.sol_id = gam.sol_id
Left Join edp_curated_prod.finacle.gac gac2 ON gac2.acid = gam.acid
Left Join edp_curated_prod.finacle.smt smt On smt.acid=gam.acid
Left Join (Select localetext,value,ROW_NUMBER() OVER (PARTITION BY value ORDER BY value) AS lcl_txt_rn
				 From edp_curated_prod.finacle.categories c
				Join edp_curated_prod.finacle.category_lang cl ON cl.categoryid = c.categoryid
				Where categorytype IN ('CUST_TYPE1', 'CUST_TYPE_DESC')) c ON c.value = a.cust_type and c.lcl_txt_rn = 1
Left Join (Select state,city,zip,orgkey,ROW_NUMBER() OVER (PARTITION BY orgkey ORDER BY orgkey) AS zip_rn
				 From edp_curated_prod.finacle.address 
				Where preferredaddress = 'Y' ) ad ON ad.orgkey = gam.cif_id and ad.zip_rn = 1
Left Join (Select REF_DESC,REF_CODE,ROW_NUMBER() OVER (PARTITION BY REF_CODE ORDER BY REF_CODE) AS stt_rn
				 From edp_curated_prod.finacle.RCT
				Where 	RCT.REF_REC_TYPE = '02'
				and RCT.Bank_id = '01'	and RCT.del_flg = 'N'	) rt ON rt.REF_CODE = ad.state and rt.stt_rn = 1
Left Join (Select REF_DESC,REF_CODE,ROW_NUMBER() OVER (PARTITION BY REF_CODE ORDER BY REF_CODE) AS ct_rn
				From edp_curated_prod.finacle.RCT
				Where RCT.REF_REC_TYPE = '01' 
				and RCT.Bank_id = '01'and RCT.del_flg = 'N' ) rt3 ON rt3.REF_CODE = ad.city and rt3.ct_rn = 1
Where gam.Acct_Cls_Flg ='N' and gam.Entity_Cre_Flg='Y' and gam.Del_Flg='N'
and gam.Schm_Type In ('SBA','CAA')
and gam.schm_code IN ('SBMIC','CABFI','CABFT')

-- COMMAND ----------

/* Transaction view */
CREATE OR REPLACE VIEW IBL_TRANSACTIONS_VW AS
With ContraAcct As (
Select	ForacID,
			h.tran_id,
			h.tran_date,
			h.part_tran_type
From  edp_curated_prod.finacle.htd h
Join  edp_curated_prod.finacle.gam g On h.acid = g.acid 
and h.pstd_flg = 'Y' and h.del_flg = 'N' )
Select	htd.dth_init_sol_id As INPUT_BR,
			gam.sol_id As ACCT_BR,
			CIF_ID As CIF_ID,
			C.FORACID As FORACID,
			schm_code As SCHM_CODE,
			schm_type As SCHM_TYPE,
			ACCT_NAME As ACCT_NAME,
			C.TRAN_ID As TRAN_ID,
			GL_DATE As GL_DATE,
			C.TRAN_DATE As TRAN_DATE,
			VALUE_DATE As VALUE_DATE,
			TRAN_AMT As TRAN_AMT,
			TRAN_TYPE As TRAN_TYPE,
			TRAN_SUB_TYPE As TRAN_SUB_TYPE,
			C.PART_TRAN_TYPE As PART_TRAN_TYPE,
			Replace(TRAN_RMKS,char(13),'') As TRAN_RMKS,
			TRAN_PARTICULAR_CODE As TRAN_PARTICULAR_CODE,
			REF_NUM As REF_NUM,
			PART_TRAN_SRL_NUM As PART_TRAN_SRL_NUM,
			 Replace(tran_particular,char(13),'') As TRAN_PARTICULAR,
			TRAN_PARTICULAR_2 As TRAN_PARTICULAR_2,
			INSTRMNT_TYPE As INSTRMNT_TYPE,
			INSTRMNT_DATE As INSTRMNT_DATE,
			INSTRMNT_NUM As INSTRMNT_NUM,
			ENTRY_USER_ID As ENTRY_USER_ID,
			PSTD_USER_ID As PSTD_USER_ID,
			VFD_USER_ID As VFD_USER_ID,
			ENTRY_DATE As ENTRY_DATE,
			PSTD_DATE As PSTD_DATE,
			VFD_DATE As VFD_DATE
From  edp_curated_prod.finacle.htd
Join  edp_curated_prod.finacle.gam On htd.acid = gam.acid
Left Join ContraAcct C On C.tran_id = htd.tran_id and C.tran_date = htd.tran_date and C.part_tran_type = (Case When htd.part_tran_type ='D' Then 'C'  When htd.part_tran_type ='C' Then 'D'  End)
Where pstd_flg = 'Y' and htd.del_flg  ='N' and (Schm_Type = 'SBA' Or Schm_Type = 'CAA' Or Schm_Type = 'TDA' )
and ((gam.foracid In ('200000266151','200000266161','201000461530','201001444217','201001444262','201002034240','00993562511618','00993562511619','00993562511620','00993562511621',
'603014023056','00993564610079','00993564615333','201002335569','201002335576','201002335583','201002335682','201002335675','00993562511622','00993562511623',
'201001788670','85003564695003','85003562593001','85003562597011','85003562599018','85003564695052','85003564695052','85003564695081'))
 Or (schm_code In ('SBMIC','RDMIC','RDMIS','CAGEN','CABFI','CABFT','IBFIL','TRMIC','TRMIS')))