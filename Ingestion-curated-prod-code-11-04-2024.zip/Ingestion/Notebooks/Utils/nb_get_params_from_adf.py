# Databricks notebook source
# Fetching ADLS details from ADF pipelines.These parameters will be passed through ADF pipeline.
def get_curated_parameters_from_adf() :
    try :
        # For logger input
        filename = 'nb_get_params_from_adf.dbc'

        # Fetching object source from ADF
        object_source = dbutils.widgets.get("object_source").lower()
        logger(logger_level_info, f"The fetching of the object source from ADF has been successfully completed.", execution_log_list, filename)

        # Fetching object name from ADF 
        object_name = dbutils.widgets.get("object_name").lower()
        logger(logger_level_info, f"The fetching of the object name from ADF has been successfully completed.", execution_log_list, filename)

        # Fetching src object id from ADF  
        src_object_id = dbutils.widgets.get("src_object_id")
        logger(logger_level_info, f"The fetching of the source object ID from ADF has been successfully completed.", execution_log_list, filename)

        # Fetching dest save type from ADF
        dest_save_type = dbutils.widgets.get("dest_save_type")
        logger(logger_level_info, f"Fetching dest save type from ADF has been successfully completed.", execution_log_list, filename)

        # Fetching load_type from ADF
        load_type = dbutils.widgets.get("load_type")
        logger(logger_level_info, f"The fetching of the load_type from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the column_to_exclude_frm_scd from ADF
        column_to_exclude_frm_scd = dbutils.widgets.get("column_to_exclude_frm_scd")
        logger(logger_level_info, f"The fetching of the 'column_to_exclude_frm_scd' from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the business_key from ADF
        business_key = dbutils.widgets.get("business_key")
        logger(logger_level_info, f"The fetching of the business_key from ADF has been successfully done.", execution_log_list, filename)

        # Fetch the load to date from ADF
        load_from_date = dbutils.widgets.get("load_from_date")
        logger(logger_level_info, f"The fetching of the load_from_date from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the load_to_date from from ADF
        load_to_date = dbutils.widgets.get("load_to_date")
        logger(logger_level_info, f"The load_to_date has been successfully fetched from ADF.", execution_log_list, filename)
        
        # Fetch the source_path from from ADF
        source_path = dbutils.widgets.get("source_path")
        logger(logger_level_info, f"The fetching of the source_path from ADF has been successfully completed.", execution_log_list, filename)
      
        # Fetch the pipeline_name from from ADF
        pipeline_name = dbutils.widgets.get("pipeline_name")
        logger(logger_level_info, f"The fetching of the pipeline_name from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the pipeline_run_id from from ADF
        pipeline_run_id = dbutils.widgets.get("pipeline_run_id")
        logger(logger_level_info, f"The fetching of the pipeline_run_id from ADF has been successfully done.", execution_log_list, filename)        

        # Fetch the pipeline_trigger_name from from ADF
        pipeline_trigger_name = dbutils.widgets.get("pipeline_trigger_name")
        logger(logger_level_info, f"The fetching of the pipeline_trigger_name from ADF has been successfully done.", execution_log_list, filename)

        # Fetch the is_dq_active from from ADF
        is_dq_active = dbutils.widgets.get("is_dq_active")
        logger(logger_level_info, f"The fetching of the is_dq_active from ADF has been successfully done.", execution_log_list, filename)

        # Fetch the adb_curated_source_url from from ADF
        adb_curated_source_url = dbutils.widgets.get("adb_curated_source_url")
        logger(logger_level_info, f"The fetching of the adb_curated_source_url from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the adb_curated_dest_url from from ADF
        adb_curated_dest_url = dbutils.widgets.get("adb_curated_dest_url")
        logger(logger_level_info, f"The fetching of the adb_curated_dest_url from ADF has been successfully completed.{adb_curated_dest_url}", execution_log_list, filename)

        # Fetch the adb_dq_dest_url from from ADF
        adb_dq_dest_url = dbutils.widgets.get("adb_dq_dest_url")
        logger(logger_level_info, f"The fetching of the adb_dq_dest_url from ADF has been successfully completed.{adb_dq_dest_url}", execution_log_list, filename)

        # Fetch the curated_schema from from ADF
        adb_curated_catlog_schema = dbutils.widgets.get("curated_schema")
        logger(logger_level_info, f"The fetching of the curated_schema from ADF has been successfully completed.{adb_curated_catlog_schema}", execution_log_list, filename)

        # Fetch the datasharing_schema from from ADF
        adb_datasharing_catlog_schema = dbutils.widgets.get("datasharing_schema")
        logger(logger_level_info, f"The fetching of the datasharing_schema from ADF has been successfully completed.{adb_datasharing_catlog_schema}", execution_log_list, filename)

        # Fetch the AKV Secret Name for Synapse JDBC connection URL 
        adb_synapse_connection_string = dbutils.widgets.get("synapse_jdbc_secret_name")
        logger(logger_level_info, f"The fetching of the synapse_jdbc_secret_name from ADF has been successfully completed.", execution_log_list, filename)

        # Defining current ETL User ID
        created_by =  spark.sql('select current_user() as user').collect()[0]['user']
        updated_by =  spark.sql('select current_user() as user').collect()[0]['user']

        return created_by, updated_by,object_source, object_name, src_object_id, dest_save_type, load_type, column_to_exclude_frm_scd, business_key, load_to_date,load_from_date, source_path, pipeline_name, pipeline_run_id, pipeline_trigger_name, is_dq_active, adb_curated_source_url, adb_curated_dest_url, adb_dq_dest_url, adb_curated_catlog_schema, adb_datasharing_catlog_schema, adb_synapse_connection_string

    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f"An error occurred while retrieving parameter details from the ADF pipeline {str(e)}.", execution_log_list, filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)