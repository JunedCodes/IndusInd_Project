# Databricks notebook source
# This Function helps in fetching the file extension of files available in provided folder_path(input)
def check_file_extension(folder_path):
    try :
        files = dbutils.fs.ls(folder_path.replace('PRAGATI_S*','PRAGATI_S1'))

        for file in files:
            file_name = file.name
            file_extension = re.search(r'\.[^.]+$', file_name)  
            
            if file_extension:
                file_extension = file_extension.group(0)
                
        return file_extension
    
    except Exception as e :
        # Log the error along with the traceback
        filename = 'nb_check_extension.dbc'
        logger(logger_level_error, f"An error occurred while checking the file extension for the path: {folder_path}.", execution_log_list, filename)    
        print(*execution_log_list,sep='\n')
        raise Exception(f"An unexpected error occurred:", e)