# Databricks notebook source
# Fetching ADLS details from ADF pipelines.These parameters will be passed through ADF pipeline.
#Change created_by ,updated_by
import inspect
def get_curated_parameters_from_adf() :

    try :
        filename='nb_curated_cb_get_curated_parameters_from_adf.dbc'
        # Defining current ETL User ID
        created_by =  spark.sql('select current_user() as user').collect()[0]['user']
        updated_by =  spark.sql('select current_user() as user').collect()[0]['user']


        # Fetching object source from ADF
        object_source = dbutils.widgets.get("object_source")
        logger(logger_level_info, f"Fetching object source from ADF has been successfully done.", execution_log_list,filename)

        # Fetching object name from ADF 
        object_name = dbutils.widgets.get("object_name").upper()
        logger(logger_level_info, f"Fetching object name from ADF has been successfully done.", execution_log_list,filename)

        # Fetching src object id from ADF  
        src_object_id = dbutils.widgets.get("src_object_id")
        logger(logger_level_info, f"Fetching src object id from ADF has been successfully done.", execution_log_list,filename)

        # Fetching load_type from ADF
        load_type = dbutils.widgets.get("load_type")
        logger(logger_level_info, f"Fetching load_type from ADF has been successfully done.", execution_log_list,filename)

        # Fetch the load to date from ADF
        load_from_date = dbutils.widgets.get("load_from_date")
        logger(logger_level_info, f"Fetching the load_from_date from ADF has been successfully done.", execution_log_list,filename)

        # Fetch the load_to_date from from ADF
        load_to_date = dbutils.widgets.get("load_to_date")
        logger(logger_level_info, f"Fetching the load_to_date from ADF has been successfully done.", execution_log_list,filename)
        
        # Fetch the source_path from from ADF
        source_path = dbutils.widgets.get("source_path")
        logger(logger_level_info, f"Fetching the source_path from ADF has been successfully done.", execution_log_list,filename)
      
        # Fetch the pipeline_name from from ADF
        pipeline_name = dbutils.widgets.get("pipeline_name")
        logger(logger_level_info, f"Fetching the pipeline_name from ADF has been successfully done.", execution_log_list,filename)

        # Fetch the pipeline_run_id from from ADF
        pipeline_run_id = dbutils.widgets.get("pipeline_run_id")
        logger(logger_level_info, f"Fetching the pipeline_run_id from ADF has been successfully done.", execution_log_list,filename)        

        # Fetch the pipeline_trigger_name from from ADF
        pipeline_trigger_name = dbutils.widgets.get("pipeline_trigger_name")
        logger(logger_level_info, f"Fetching the pipeline_trigger_name from ADF has been successfully done.", execution_log_list,filename)

        # Fetch the triggered_by_pipeline from from ADF
        triggered_by_pipeline = dbutils.widgets.get("triggered_by_pipeline")
        logger(logger_level_info, f"Fetching the triggered_by_pipeline from ADF has been successfully done.", execution_log_list,filename)

        # Fetching the created_by value from ADF
        archive_container = dbutils.widgets.get("archive_container") 
        logger(logger_level_info, f"Fetching the archive_container value from ADF has been successfully done.", execution_log_list,filename)

        last_load_to_date= dbutils.widgets.get("last_load_to_date") 
        logger(logger_level_info, f"Fetching the last_load_to_date value from ADF has been successfully done.", execution_log_list,filename)

        desti_container= dbutils.widgets.get("desti_container") 
        logger(logger_level_info, f"Fetching the desti_container value from ADF has been successfully done.", execution_log_list,filename)

        # Fetch the adb_curated_source_url from from ADF
        adb_curated_source_url = dbutils.widgets.get("adb_curated_source_url")
        logger(logger_level_info, f"The fetching of the adb_curated_source_url from ADF has been successfully completed.", execution_log_list, filename)

        # Fetch the AKV Secret Name for Synapse JDBC connection URL 
        adb_synapse_connection_string = dbutils.widgets.get("synapse_jdbc_secret_name")
        logger(logger_level_info, f"The fetching of the synapse_jdbc_secret_name from ADF has been successfully completed.", execution_log_list, filename)



        return src_object_id,pipeline_run_id,load_from_date,load_to_date,pipeline_name,object_source, object_name, load_type,desti_container,last_load_to_date, source_path,pipeline_trigger_name,triggered_by_pipeline, archive_container,created_by,updated_by,adb_curated_source_url,adb_synapse_connection_string
    except Exception as e:
        # Call the logger function with a log level and message
        logger(logger_level_error, f" error occurs while fetching parameters details from ADF pipeline", execution_log_list,filename)
        print(*execution_log_list,sep='\n')
        raise Exception(f" error occurs while fetching parameters details from ADF pipeline")