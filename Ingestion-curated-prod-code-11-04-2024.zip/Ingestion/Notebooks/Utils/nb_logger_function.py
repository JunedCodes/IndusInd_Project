# Databricks notebook source
# Define the logger function
def logger(level, message, execution_log_list, filename):
    cf = inspect.currentframe()
    current_time = datetime.now(pytz.timezone('Asia/Kolkata')).strftime('%Y-%m-%dT%H:%M:%SZ')
    execution_log_list.append(f"{current_time} | {level} | {filename} | {message}")